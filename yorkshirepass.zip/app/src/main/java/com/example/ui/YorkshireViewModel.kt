package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface AiState {
    object Idle : AiState
    object Loading : AiState
    data class Success(val response: String) : AiState
    data class Error(val message: String) : AiState
}

class YorkshireViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = YorkshireRepository(application)

    // Reactively observe local DB tables
    val bookings: StateFlow<List<Booking>> = repository.allBookings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stamps: StateFlow<List<Stamp>> = repository.allStamps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val badges: StateFlow<List<Badge>> = repository.allBadges
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val itineraries: StateFlow<List<Itinerary>> = repository.allItineraries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state
    val attractions: List<Attraction> = repository.attractions
    val events: List<YorkshireEvent> = repository.events

    // Active pass level (Free, Explorer, Premium, Gold)
    var selectedTier by mutableStateOf("Premium")

    // Dynamic filters for Explore Screen
    var selectedFilter by mutableStateOf("Heritage")

    // AI States
    private val _itineraryAiState = MutableStateFlow<AiState>(AiState.Idle)
    val itineraryAiState: StateFlow<AiState> = _itineraryAiState.asStateFlow()

    private val _chatAiState = MutableStateFlow<AiState>(AiState.Idle)
    val chatAiState: StateFlow<AiState> = _chatAiState.asStateFlow()

    // Chats history
    private val _chatHistory = MutableStateFlow<List<Pair<String, String>>>(
        listOf("AI Guide" to "How do you do! I'm your official AI Yorkshire Guide. Ask me anything about trains, abbeys, hotels, or plan a romantic escape.")
    )
    val chatHistory: StateFlow<List<Pair<String, String>>> = _chatHistory.asStateFlow()

    // Offline mode toggle
    var offlineModeEnabled by mutableStateOf(false)
    var downloadedMaps by mutableStateOf(false)
    var downloadedTickets by mutableStateOf(false)

    init {
        viewModelScope.launch {
            repository.populateInitialDataIfNeeded()
        }
    }

    // --- Actions ---

    fun bookAttraction(attraction: Attraction) {
        viewModelScope.launch {
            repository.addBooking(
                title = attraction.title,
                type = "Attraction",
                dateTime = "Today, 2:00 PM",
                qrData = "ATTRACTION_${attraction.id}_PASS",
                price = if (selectedTier == "Premium" || selectedTier == "Gold") "Included (Pass)" else attraction.entryPrice,
                location = attraction.location
            )
        }
    }

    fun bookRail(title: String, price: String) {
        viewModelScope.launch {
            repository.addBooking(
                title = title,
                type = "Rail",
                dateTime = "Tomorrow, 9:15 AM",
                qrData = "RAIL_TICKET_" + (1000..9999).random(),
                price = price,
                location = "Yorkshire Rail Network"
            )
        }
    }

    fun bookHotel(title: String, location: String, price: String) {
        viewModelScope.launch {
            repository.addBooking(
                title = title,
                type = "Hotel",
                dateTime = "Check-in: Fri, 4:00 PM",
                qrData = "HOTEL_RESERVATION_" + (10000..99999).random(),
                price = price,
                location = location
            )
        }
    }

    fun deleteBooking(booking: Booking) {
        viewModelScope.launch {
            repository.deleteBooking(booking.id)
        }
    }

    fun collectStamp(id: String) {
        viewModelScope.launch {
            repository.collectStamp(id)
        }
    }

    fun resetPassport() {
        viewModelScope.launch {
            repository.resetPassport()
        }
    }

    fun buildItinerary(days: Int, budget: String, interests: String, transportMode: String) {
        _itineraryAiState.value = AiState.Loading
        viewModelScope.launch {
            try {
                val result = repository.buildAndSaveItinerary(days, budget, interests, transportMode)
                _itineraryAiState.value = AiState.Success(result)
            } catch (e: Exception) {
                _itineraryAiState.value = AiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun sendChatQuery(query: String) {
        if (query.isBlank()) return
        // Add user query to chat history
        _chatHistory.value = _chatHistory.value + ("User" to query)
        _chatAiState.value = AiState.Loading

        viewModelScope.launch {
            try {
                val result = repository.askYorkshireGuide(query)
                _chatHistory.value = _chatHistory.value + ("AI Guide" to result)
                _chatAiState.value = AiState.Success(result)
            } catch (e: Exception) {
                val errMsg = e.message ?: "Unknown error contacting AI"
                _chatHistory.value = _chatHistory.value + ("AI Guide" to "Apologies, I encountered a connection hitch: $errMsg. I am currently offline.")
                _chatAiState.value = AiState.Error(errMsg)
            }
        }
    }

    fun clearChat() {
        _chatHistory.value = listOf(
            "AI Guide" to "How do you do! I'm your official AI Yorkshire Guide. Ask me anything about trains, abbeys, hotels, or plan a romantic escape."
        )
        _chatAiState.value = AiState.Idle
    }
}
