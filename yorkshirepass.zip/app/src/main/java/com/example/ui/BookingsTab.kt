package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Booking
import kotlin.math.absoluteValue

@Composable
fun BookingsTab(viewModel: YorkshireViewModel) {
    val context = LocalContext.current
    val bookings by viewModel.bookings.collectAsState()
    var selectedBookingForQr by remember { mutableStateOf<Booking?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "My Digital Wallet",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Show QR tickets below to enter attractions or board trains.",
                fontSize = 13.sp,
                color = Color.Gray
            )
        }

        // 2. Day Trip by Rail Special Feature Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("day_trip_rail_banner"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Train,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Day Trip by Rail Special",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White,
                        fontFamily = FontFamily.Serif
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "One tap builds a seamless rail excursion. Instantly books York-Whitby Train, Whitby Abbey entrance, and coastal lunch reservation!",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.9f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        // Book all 3 excursions instantly
                        viewModel.bookRail("Day Trip: Scenic York to Whitby Return", "Included (Pass)")
                        viewModel.bookHotel("Lunch Booking: Papa's Fish & Chips (Whitby)", "Whitby Pier YO21", "Table Reserved")
                        viewModel.bookRail("Admission: Whitby Abbey Explorer Pass", "Included (Pass)")
                        
                        Toast.makeText(context, "🚂 3 Excursion passes booked into your Wallet!", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    modifier = Modifier.align(Alignment.End),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text("Book Full Trip Now", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Tickets/Passes List
        if (bookings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.ConfirmationNumber,
                        contentDescription = "Empty wallet",
                        tint = Color.LightGray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Your Wallet is Empty",
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Text(
                        text = "Go to 'Explore' to reserve local attractions or trigger 'Day Trip by Rail'!",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(start = 32.dp, end = 32.dp, top = 4.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                items(bookings) { booking ->
                    WalletTicket(
                        booking = booking,
                        onShowQr = { selectedBookingForQr = booking },
                        onCancel = { viewModel.deleteBooking(booking) }
                    )
                }
            }
        }
    }

    // --- QR Code Bottom Sheet / Dialog ---
    selectedBookingForQr?.let { booking ->
        AlertDialog(
            onDismissRequest = { selectedBookingForQr = null },
            confirmButton = {
                TextButton(onClick = { selectedBookingForQr = null }) { Text("Close") }
            },
            title = {
                Text(
                    text = "Verify Ticket Pass",
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = MaterialTheme.colorScheme.primary
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(booking.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center)
                    Text(booking.location, fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
                    
                    Spacer(modifier = Modifier.height(16.dp))

                    // Simulated QR Graphic
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Drawing a fake barcode/QR pattern on canvas
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val cellSize = size.width / 10
                            for (row in 0..9) {
                                for (col in 0..9) {
                                    // Generate a deterministic pseudo-random grid based on the booking ref
                                    val seed = (booking.bookingRef.hashCode() + row * 17 + col * 31).absoluteValue
                                    if (seed % 2 == 0 || (row in 0..2 && col in 0..2) || (row in 7..9 && col in 0..2) || (row in 0..2 && col in 7..9)) {
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset(col * cellSize, row * cellSize),
                                            size = androidx.compose.ui.geometry.Size(cellSize, cellSize)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Booking Ref: ${booking.bookingRef}",
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Secure Pass • Scanned at gates for entry",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        )
    }
}

@Composable
fun WalletTicket(
    booking: Booking,
    onShowQr: () -> Unit,
    onCancel: () -> Unit
) {
    // Elegant ticket container with dashed dividing line
    val primaryColor = when (booking.type) {
        "Rail" -> Color(0xFFC5A059) // Gold/Brass for travel
        "Hotel" -> Color(0xFF1E3D6B) // Dark Blue for lodging
        "Restaurant" -> Color(0xFF15803D) // Green for dining
        else -> Color(0xFF0B2240) // Deep Blue for Attractions
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("wallet_ticket_item"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column {
            // Top ticket header half
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(primaryColor)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = when (booking.type) {
                        "Rail" -> Icons.Filled.Train
                        "Hotel" -> Icons.Filled.Hotel
                        "Restaurant" -> Icons.Filled.LocalDining
                        else -> Icons.Filled.ConfirmationNumber
                    },
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = booking.type.uppercase(),
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "REF: ${booking.bookingRef}",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            // Middle ticket details half
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = booking.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "DATE & TIME", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text(text = booking.dateTime, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "PRICE STATUS", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text(text = booking.price, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = primaryColor)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocationOn, "Location", tint = Color.Gray, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = booking.location, fontSize = 11.sp, color = Color.Gray)
                }

                // Custom Dashed Divider (Simulating tear strip)
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .drawBehind {
                            drawLine(
                                color = Color.LightGray,
                                start = Offset(0f, 0f),
                                end = Offset(size.width, 0f),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                            )
                        }
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Action Footer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onCancel,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.Red),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Filled.Delete, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Cancel", fontSize = 12.sp)
                    }
                    
                    Button(
                        onClick = onShowQr,
                        colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Filled.QrCode, null, modifier = Modifier.size(14.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Scan Ticket", fontSize = 11.sp, color = Color.White)
                    }
                }
            }
        }
    }
}
