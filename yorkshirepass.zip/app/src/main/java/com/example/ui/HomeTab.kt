package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.YorkshireEvent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTab(viewModel: YorkshireViewModel, onNavigateToTab: (Int) -> Unit) {
    val scrollState = rememberScrollState()
    val events = viewModel.events
    
    // Bottom Sheet states for detailed sub-sections
    var showRailDepartures by remember { mutableStateOf(false) }
    var showCoastMode by remember { mutableStateOf(false) }
    var showHeritageRailMode by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Landscape Hero Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_yorkshire_hero_1784711699986),
                contentDescription = "Breathtaking Yorkshire Dales landscape",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Premium gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)),
                            startY = 100f
                        )
                    )
            )

            // Greeting and Overlay text
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(20.dp)
            ) {
                Text(
                    text = "Good Morning, Welcome to Yorkshire",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
                Text(
                    text = "One Pass. One County. Unlimited Yorkshire.",
                    color = Color(0xFFD4AF37), // Brass Gold Accent
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // Membership badge
            Surface(
                color = MaterialTheme.colorScheme.tertiary,
                shape = RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 20.dp)
            ) {
                Text(
                    text = viewModel.selectedTier.uppercase(),
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        // 2. Main Content Wrapper
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // My Pass Status Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1D2B45)
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(176.dp)
                    .testTag("my_pass_status_card")
                    .clickable { onNavigateToTab(3) } // Corrected index for Pass Tab (0-Home, 1-Explore, 2-Bookings, 3-Pass, 4-AI, 5-Profile)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        // Membership Badge
                        Surface(
                            color = Color(0xFFC5A059), // Brass gold accent
                            shape = RoundedCornerShape(50),
                        ) {
                            Text(
                                text = "${viewModel.selectedTier} Member".uppercase(),
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                letterSpacing = 0.5.sp
                            )
                        }
                        
                        // Right side info
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "YORK MINSTER",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Next Entry: 11:30",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                    
                    // Bottom Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "MY DIGITAL PASS",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "YP-992-004-X",
                                color = Color.White,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = (-0.5).sp
                            )
                        }
                        
                        // Small QR layout representation
                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .padding(6.dp)
                                    .fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.QrCodeScanner,
                                    contentDescription = "QR Code",
                                    tint = Color.Black,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }

            // Quick Insights (Anglo-Futurist Rail & Weather Status)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Rail Status
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { showRailDepartures = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFC5A059).copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth()
                    ) {
                        Text(
                            text = "RAIL STATUS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "10:15 Harrogate",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ON TIME",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF16A34A)
                        )
                    }
                }

                // Weather
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { showCoastMode = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFC5A059).copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth()
                    ) {
                        Text(
                            text = "WEATHER",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Whitby Coast",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "14°C • MISTY",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Quick Actions Title
            Text(
                text = "County Tourism Portals",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 4.dp)
            )

            // Grid Layout for Portals
            Row(modifier = Modifier.fillMaxWidth()) {
                // Left Column
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    PortalCard(
                        title = "Heritage Rail Mode",
                        description = "Steam Galas, Dining Trains, Pullman Specials",
                        icon = Icons.Filled.Train,
                        color = Color(0xFFC5A059), // Brass Accent
                        onClick = { showHeritageRailMode = true }
                    )
                    PortalCard(
                        title = "Coast & Beaches",
                        description = "Tide Times, Fish & Chips Guide, Coastal Webcams",
                        icon = Icons.Filled.Waves,
                        color = Color(0xFF1E3D6B), // Deep Blue
                        onClick = { showCoastMode = true }
                    )
                }

                // Right Column
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    PortalCard(
                        title = "Integrated Rail Strategy",
                        description = "Live departures, Rail itineraries, Alerts",
                        icon = Icons.Filled.DepartureBoard,
                        color = Color(0xFF475569), // Stone Grey
                        onClick = { showRailDepartures = true }
                    )
                    PortalCard(
                        title = "Food Stamp Passport",
                        description = "Collect digital stamps at pubs, cafés & breweries",
                        icon = Icons.Filled.LocalPizza,
                        color = Color(0xFF15803D), // Green
                        onClick = { onNavigateToTab(3) } // Pass tab (has food stamps)
                    )
                }
            }

            // Upcoming events
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Yorkshire Event Calendar",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = MaterialTheme.colorScheme.primary
                )
                TextButton(onClick = { onNavigateToTab(1) }) {
                    Text("Explore All", color = MaterialTheme.colorScheme.tertiary)
                }
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(events) { event ->
                    EventCard(event = event)
                }
            }
            
            // Helpful AI Quick Banner
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "AI",
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Smart AI Itinerary Planner",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Create custom multi-day journeys across Yorkshire instantly with AI.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                    Button(
                        onClick = { onNavigateToTab(4) }, // AI Guide Tab is index 4 (0-Home, 1-Explore, 2-Bookings, 3-Pass, 4-AI, 5-Profile)
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.tertiary
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Launch", fontSize = 11.sp, color = Color.White)
                    }
                }
            }
        }
    }

    // --- Bottom Sheet Portals ---

    // 1. Integrated Rail strategy
    if (showRailDepartures) {
        AlertDialog(
            onDismissRequest = { showRailDepartures = false },
            confirmButton = {
                TextButton(onClick = { showRailDepartures = false }) { Text("Close") }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.DepartureBoard, contentDescription = null, tint = Color(0xFF0B2240))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("York Station Live Board")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Real-Time Departures & Platform Alerts",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    DepartureRow("09:12", "London Kings Cross", "LNER", "Plat 3", "On Time")
                    DepartureRow("09:24", "Newcastle", "CrossCountry", "Plat 5", "On Time")
                    DepartureRow("09:35", "Whitby (Scenic Moorse)", "Northern Rail", "Plat 8", "On Time")
                    DepartureRow("09:48", "Leeds (Direct)", "TransPennine", "Plat 1", "Delayed 5m")
                    DepartureRow("10:02", "Scarborough Coast Express", "TransPennine", "Plat 2", "On Time")

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, "Alert", tint = MaterialTheme.colorScheme.onErrorContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Service Alert: Heavy leaf fall on lines between Skipton and Carlisle. Expect slight delays.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Button(
                        onClick = {
                            viewModel.bookRail("Scenic Day Pass: York to Whitby Express", "£24.00")
                            showRailDepartures = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Add Ticket to My Wallet (Scenic Day Pass)")
                    }
                }
            }
        )
    }

    // 2. Coast & Beaches Mode
    if (showCoastMode) {
        AlertDialog(
            onDismissRequest = { showCoastMode = false },
            confirmButton = {
                TextButton(onClick = { showCoastMode = false }) { Text("Close") }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Waves, contentDescription = null, tint = Color(0xFF1E3D6B))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Yorkshire Coast Mode")
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Current Conditions & Culinary Guide",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    CoastWeatherCard("Whitby Coast", "Low Tide: 1:35 PM • Sea: Gentle 1.2m swells • Temp: 19°C")
                    CoastWeatherCard("Scarborough", "High Tide: 10:14 AM • Sea: Moderately choppy • Temp: 18°C")
                    CoastWeatherCard("Filey Beach", "Low Tide: 2:05 PM • Sea: Calme flat • Temp: 20°C")

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Fish & Chips Highlights", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        "• Magpie Café (Whitby): Renowned line-caught haddock fried in pure beef dripping. Expect a line, completely worth it!\n" +
                        "• Papa's Fish & Chips (Scarborough): Located right on the South Bay wharf with live webcams inside the queue.\n" +
                        "• Filey Bistro: Quiet, cozy spot on beach edge offering giant cod baps.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Live Beach Webcams", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(60.dp)
                                .background(Color.Black, RoundedCornerShape(6.dp))
                        ) {
                            Text("WHITBY LIVE", color = Color.Green, fontSize = 9.sp, modifier = Modifier.align(Alignment.Center))
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(60.dp)
                                .background(Color.Black, RoundedCornerShape(6.dp))
                        ) {
                            Text("SCARB. CAM", color = Color.Green, fontSize = 9.sp, modifier = Modifier.align(Alignment.Center))
                        }
                    }
                }
            }
        )
    }

    // 3. Heritage Rail Mode
    if (showHeritageRailMode) {
        AlertDialog(
            onDismissRequest = { showHeritageRailMode = false },
            confirmButton = {
                TextButton(onClick = { showHeritageRailMode = false }) { Text("Close") }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Train, contentDescription = null, tint = Color(0xFFC5A059))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Heritage Railway Mode")
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Vintage Steam Schedules & Luxury Charters",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFFC5A059)
                    )

                    Text(
                        "• Steam Gala Express (NYMR): Standard steam schedules running Pickering - Whitby. Daily departures starting 09:30 AM.\n" +
                        "• Luxury Pullman Dining Trains: Enjoy a complete 3-course roast lunch or high tea in pristine 1930s mahogany parlour carriages.\n" +
                        "• Keighley Worth Valley: Special locomotive photography charters active on Haworth loop this weekend.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Active Locomotive Tracker", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    
                    LocoRow("LNER Class A4 'Mallard'", "Active", "Running Pickering to Levisham")
                    LocoRow("BR Standard Class 4MT", "In Shed", "Maintenance at Grosmont")
                    LocoRow("LMS Stanier Class 5 'Black 5'", "Active", "Running Goathland to Whitby")

                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            viewModel.bookRail("NYMR Luxury Afternoon Tea Train Reservation", "£45.00")
                            showHeritageRailMode = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC5A059)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Reserve Pullman Afternoon Tea Seat", color = Color.White)
                    }
                }
            }
        )
    }
}

@Composable
fun PortalCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(28.dp)
            )
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = color
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
fun EventCard(event: YorkshireEvent) {
    Card(
        modifier = Modifier
            .width(260.dp)
            .height(140.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = event.category,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = event.date,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = event.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = event.description,
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Filled.LocationOn,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = event.location,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@Composable
fun DepartureRow(time: String, dest: String, operator: String, platform: String, status: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(time, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(dest, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            }
            Text("$operator • $platform", fontSize = 11.sp, color = Color.Gray)
        }
        Text(
            text = status,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = if (status == "On Time") Color(0xFF15803D) else Color(0xFFDC2626)
        )
    }
}

@Composable
fun CoastWeatherCard(location: String, info: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(location, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(info, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
        }
    }
}

@Composable
fun LocoRow(name: String, status: String, activity: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.Medium, fontSize = 12.sp)
            Text(activity, fontSize = 10.sp, color = Color.Gray)
        }
        Surface(
            color = if (status == "Active") Color(0xFFDCFCE7) else Color(0xFFF1F5F9),
            shape = RoundedCornerShape(4.dp)
        ) {
            Text(
                text = status,
                color = if (status == "Active") Color(0xFF15803D) else Color(0xFF475569),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
