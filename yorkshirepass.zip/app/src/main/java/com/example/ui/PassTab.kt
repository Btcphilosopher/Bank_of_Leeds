package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Badge
import com.example.data.Stamp

@Composable
fun PassTab(viewModel: YorkshireViewModel) {
    val context = LocalContext.current
    val stamps by viewModel.stamps.collectAsState()
    val badges by viewModel.badges.collectAsState()

    // Sub-tab selection: 0-Food Passport, 1-Yorkshire Achievements, 2-Badges
    var subTabState by remember { mutableStateOf(0) }

    val foodStamps = stamps.filter { it.category == "Food" }
    val passportStamps = stamps.filter { it.category == "Passport" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "County Passport & Badges",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Earn stamps and claim rewards by visiting local partners.",
                fontSize = 13.sp,
                color = Color.Gray
            )
        }

        // 2. Sub Tab Navigation
        TabRow(selectedTabIndex = subTabState) {
            Tab(
                selected = subTabState == 0,
                onClick = { subTabState = 0 },
                text = { Text("Food Passport", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Filled.LocalCafe, null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = subTabState == 1,
                onClick = { subTabState = 1 },
                text = { Text("Heritage Pass", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Filled.Castle, null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = subTabState == 2,
                onClick = { subTabState = 2 },
                text = { Text("Badges (${badges.count { it.isUnlocked }}/${badges.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Filled.Star, null, modifier = Modifier.size(18.dp)) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Dynamic Passport Board
        AnimatedContent(
            targetState = subTabState,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "PassportSubTabContent"
        ) { tabIndex ->
            when (tabIndex) {
                0 -> {
                    // FOOD PASSPORT
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Reward progress card
                        val foodUnlockedCount = foodStamps.count { it.isUnlocked }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Food & Drink Reward Status",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { foodUnlockedCount.toFloat() / foodStamps.size },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = Color(0xFFC5A059),
                                    trackColor = Color.White
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (foodUnlockedCount >= 3) {
                                        "🎉 Reward Unlocked: Free Traditional Yorkshire Pudding Dessert at participating inns! Show this screen to your server."
                                    } else {
                                        "Collect ${3 - foodUnlockedCount} more stamps to unlock a free dessert at local country pubs!"
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)
                                )
                            }
                        }

                        // Grid of Food Stamps
                        Text(
                            text = "Scan or Tap venue to collect stamp",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("food_passport_grid")
                        ) {
                            items(foodStamps) { stamp ->
                                StampBox(stamp = stamp) {
                                    viewModel.collectStamp(stamp.id)
                                    Toast.makeText(context, "Stamp Collected: ${stamp.title}!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // HERITAGE PASSPORT
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        val passUnlockedCount = passportStamps.count { it.isUnlocked }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFC5A059).copy(alpha = 0.1f)),
                            border = BorderStroke(1.dp, Color(0xFFC5A059).copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Grand Yorkshire Achievements",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFFC5A059)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Visits: $passUnlockedCount / ${passportStamps.size} key county destinations stamped. Explore castles, abbeys, and railways to complete the set!",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                )
                            }
                        }

                        Text(
                            text = "Historical & Natural Landmarks",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("heritage_passport_grid")
                        ) {
                            items(passportStamps) { stamp ->
                                StampBox(stamp = stamp) {
                                    viewModel.collectStamp(stamp.id)
                                    Toast.makeText(context, "Stamp Collected: ${stamp.title}!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // BADGES BOARD
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(1),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("badges_list")
                    ) {
                        items(badges) { badge ->
                            BadgeCard(badge = badge)
                        }

                        item {
                            Spacer(modifier = Modifier.height(16.dp))
                            OutlinedButton(
                                onClick = {
                                    viewModel.resetPassport()
                                    Toast.makeText(context, "All stamps and badges reset!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                                border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Reset Passport stamps")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StampBox(stamp: Stamp, onCollect: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clickable { if (!stamp.isUnlocked) onCollect() },
        colors = CardDefaults.cardColors(
            containerColor = if (stamp.isUnlocked) Color(0xFFFDFBF7) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (stamp.isUnlocked) Color(0xFFC5A059) else MaterialTheme.colorScheme.outlineVariant
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Visual stamp seal representation
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        color = if (stamp.isUnlocked) Color(0xFFC5A059).copy(alpha = 0.15f) else Color.LightGray.copy(alpha = 0.2f),
                        shape = CircleShape
                    )
                    .border(
                        width = 1.dp,
                        color = if (stamp.isUnlocked) Color(0xFFC5A059) else Color.LightGray,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (stamp.isUnlocked) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = "Stamped",
                        tint = Color(0xFFC5A059),
                        modifier = Modifier.size(24.dp)
                    )
                } else {
                    Icon(
                        imageVector = when (stamp.subCategory) {
                            "Cathedral" -> Icons.Filled.Church
                            "Castle" -> Icons.Filled.Castle
                            "Heritage Rail" -> Icons.Filled.Train
                            "National Park" -> Icons.Filled.Terrain
                            "Coastal Town" -> Icons.Filled.Waves
                            "Brewery" -> Icons.Filled.LocalBar
                            "Cafe" -> Icons.Filled.LocalCafe
                            "Pub" -> Icons.Filled.Restaurant
                            else -> Icons.Filled.LocalActivity
                        },
                        contentDescription = "Unstamped",
                        tint = Color.LightGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = stamp.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = if (stamp.isUnlocked) "STAMPED: ${stamp.dateUnlocked}" else "TAP TO SCAN STAMP",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (stamp.isUnlocked) Color(0xFFC5A059) else Color.Gray,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun BadgeCard(badge: Badge) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (badge.isUnlocked) Color(0xFFF8FAFC) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = if (badge.isUnlocked) 1.5.dp else 1.dp,
            color = if (badge.isUnlocked) Color(0xFFD4AF37) else MaterialTheme.colorScheme.outlineVariant
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Shiny circle badge representation
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(
                        color = if (badge.isUnlocked) Color(0xFFFDE047).copy(alpha = 0.2f) else Color.LightGray.copy(alpha = 0.1f),
                        shape = CircleShape
                    )
                    .border(
                        width = 2.dp,
                        color = if (badge.isUnlocked) Color(0xFFD4AF37) else Color.LightGray,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (badge.isUnlocked) Icons.Filled.Stars else Icons.Filled.Lock,
                    contentDescription = null,
                    tint = if (badge.isUnlocked) Color(0xFFD4AF37) else Color.LightGray,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = badge.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = if (badge.isUnlocked) MaterialTheme.colorScheme.primary else Color.Gray
                )
                Text(
                    text = badge.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                if (badge.isUnlocked) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Unlocked on ${badge.dateUnlocked}",
                        fontSize = 10.sp,
                        color = Color(0xFFC5A059),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
