package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ProfileTab(viewModel: YorkshireViewModel) {
    val scrollState = rememberScrollState()
    var activePortalState by remember { mutableStateOf(0) } // 0-User Profile, 1-Partner Dashboard

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Account & Settings",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            )
            
            Spacer(modifier = Modifier.height(12.dp))

            // Selector for User Profile vs Partner Dashboard
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = activePortalState == 0,
                    onClick = { activePortalState = 0 },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Person, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Traveler Pass")
                    }
                }
                SegmentedButton(
                    selected = activePortalState == 1,
                    onClick = { activePortalState = 1 },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Dashboard, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Partner Portal")
                    }
                }
            }
        }

        AnimatedContent(
            targetState = activePortalState,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "PortalToggle"
        ) { portal ->
            if (portal == 0) {
                UserProfileView(viewModel)
            } else {
                BusinessDashboardView()
            }
        }
    }
}

@Composable
fun UserProfileView(viewModel: YorkshireViewModel) {
    val coroutineScope = rememberCoroutineScope()
    var mapDownloadProgress by remember { mutableStateOf(0f) }
    var isDownloadingMap by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Traveler Card Info
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Initial Circle Avatar
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("T", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Tom Bradshaw", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Member since August 2024", fontSize = 12.sp, color = Color.Gray)
                    Surface(
                        color = Color(0xFFC5A059).copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            text = "${viewModel.selectedTier.uppercase()} TIER ACTIVE",
                            color = Color(0xFFC5A059),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Membership Tier selection
        Text(
            text = "Upgrade YorkshirePass Tier",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            fontFamily = FontFamily.Serif
        )

        val tiers = listOf(
            Triple("Free", "Digital Maps & Events Calendar", "Free"),
            Triple("Explorer", "Local restaurant offers & hotel discounts", "£29/yr"),
            Triple("Premium", "Attractions admissions, abbeys & abbeys heritage rail", "£99/yr"),
            Triple("Gold", "VIP fast-track, exclusive events & hotel upgrades", "£249/yr")
        )

        tiers.forEach { (name, desc, price) ->
            val isSelected = viewModel.selectedTier == name
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectedTier = name }
                    .testTag("tier_card_$name"),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(
                    width = if (isSelected) 1.5.dp else 1.dp,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { viewModel.selectedTier = name }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = desc, fontSize = 11.sp, color = Color.Gray)
                    }
                    Text(
                        text = price,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Offline mode controls
        Text(
            text = "Offline Mode Configuration",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            fontFamily = FontFamily.Serif,
            modifier = Modifier.padding(top = 8.dp)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Main offline mode switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Force Offline Mode", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Runs the applet strictly on cached data, great for Dales hikes with zero signal.", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(
                        checked = viewModel.offlineModeEnabled,
                        onCheckedChange = { viewModel.offlineModeEnabled = it }
                    )
                }

                HorizontalDivider()

                // Download Toggle 1
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Download County Vector Maps (74 MB)", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        Text(
                            text = if (viewModel.downloadedMaps) "Vector map cache available locally" else "Offline schematic directory ready for download",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    if (viewModel.downloadedMaps) {
                        Icon(Icons.Filled.CheckCircle, "Downloaded", tint = Color(0xFF15803D))
                    } else if (isDownloadingMap) {
                        Text("${(mapDownloadProgress * 100).toInt()}%", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    } else {
                        IconButton(
                            onClick = {
                                isDownloadingMap = true
                                coroutineScope.launch {
                                    while (mapDownloadProgress < 1.0f) {
                                        delay(150)
                                        mapDownloadProgress += 0.1f
                                    }
                                    isDownloadingMap = false
                                    viewModel.downloadedMaps = true
                                }
                            }
                        ) {
                            Icon(Icons.Filled.Download, "Download", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                if (isDownloadingMap) {
                    LinearProgressIndicator(
                        progress = { mapDownloadProgress },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Download Toggle 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Cache Digital QR Passes & Itineraries", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        Text(text = "Ensures all booked tickets render flawlessly offline", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(
                        checked = viewModel.downloadedTickets,
                        onCheckedChange = { viewModel.downloadedTickets = it }
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun BusinessDashboardView() {
    Column(
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Portal Credentials Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), // Sleek Midnight
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Security, null, tint = Color(0xFFD4AF37))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Secure Partner Portal Active",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Operator views and anonymized tourism metrics for Yorkshire local attractions.",
                    color = Color.LightGray,
                    fontSize = 11.sp
                )
            }
        }

        // Widget 1: Revenue & Admissions
        Text(
            text = "Operational Metrics & Revenue",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            fontFamily = FontFamily.Serif
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DashboardMetricCard(
                title = "Redemptions (Wk)",
                value = "1,842 passes",
                trend = "+12% vs last wk",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            DashboardMetricCard(
                title = "Partner Revenue",
                value = "£14,820.00",
                trend = "Payout scheduled Fri",
                color = Color(0xFF15803D),
                modifier = Modifier.weight(1f)
            )
        }

        // Widget 2: Redeemed lists table
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Weekly Redemptions by Attraction",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                RedemptionRow("York Minster", "452", "£8,136.00")
                RedemptionRow("Castle Howard", "312", "£6,864.00")
                RedemptionRow("Jorvik Viking Centre", "542", "£8,130.00")
                RedemptionRow("Whitby Abbey Pass", "282", "£3,384.00")
                RedemptionRow("NYMR Steam Ride Rover", "254", "£10,160.00")
            }
        }

        // Widget 3: Demographic Breakdown (Anonymized pie chart)
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Visitor Regional Demographics",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(10.dp))
                // Simulated Horizontal Demographic Bars
                DemographicBar("United Kingdom (Domestic)", 0.65f, "65%", Color(0xFF0B2240))
                DemographicBar("United States & Canada", 0.18f, "18%", Color(0xFFC5A059))
                DemographicBar("Europe Union (EU)", 0.12f, "12%", Color(0xFF475569))
                DemographicBar("Asia-Pacific & Others", 0.05f, "5%", Color(0xFF94A3B8))
            }
        }

        // Widget 4: Heat Map forecast
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Peak Occupancy Heatmap Forecast (Sat)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                OccupancyHeatRow("York Minster (Center Hub)", "Peak Expect: 2:00 PM • 90% Occupancy", Color(0xFFDC2626))
                OccupancyHeatRow("Whitby Abbey cliffside", "Peak Expect: 1:00 PM • 75% Occupancy", Color(0xFFEA580C))
                OccupancyHeatRow("Fountains Abbey grounds", "Peak Expect: 11:00 AM • 45% Occupancy", Color(0xFFCA8A04))
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun DashboardMetricCard(
    title: String,
    value: String,
    trend: String,
    color: Color,
    modifier: Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.05f)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
            Spacer(modifier = Modifier.height(2.dp))
            Text(trend, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun RedemptionRow(attraction: String, count: String, payout: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(attraction, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text("$count scans", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.End, modifier = Modifier.width(80.dp))
        Text(payout, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D), textAlign = TextAlign.End, modifier = Modifier.width(80.dp))
    }
}

@Composable
fun DemographicBar(region: String, fraction: Float, percentage: String, barColor: Color) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(region, fontSize = 11.sp)
            Text(percentage, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        // Visual Bar representation
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .background(Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(3.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
                    .background(barColor, RoundedCornerShape(3.dp))
            )
        }
    }
}

@Composable
fun OccupancyHeatRow(location: String, forecast: String, heatColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(heatColor, CircleShape)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(location, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(forecast, fontSize = 11.sp, color = Color.Gray)
        }
    }
}
