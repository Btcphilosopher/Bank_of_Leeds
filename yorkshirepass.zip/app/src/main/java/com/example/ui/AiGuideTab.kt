package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun AiGuideTab(viewModel: YorkshireViewModel) {
    // Tab selector: 0-Smart Itinerary Builder, 1-Ask AI Guide Chat
    var innerTabState by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Title block
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Yorkshire AI Companion",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Powered by Gemini AI to plan the ultimate county tour.",
                fontSize = 13.sp,
                color = Color.Gray
            )
        }

        // 2. Tab selection
        TabRow(selectedTabIndex = innerTabState) {
            Tab(
                selected = innerTabState == 0,
                onClick = { innerTabState = 0 },
                text = { Text("Itinerary Builder", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Filled.AutoAwesome, null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = innerTabState == 1,
                onClick = { innerTabState = 1 },
                text = { Text("AI Travel Chat", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Filled.Forum, null, modifier = Modifier.size(18.dp)) }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3. Content Panel
        AnimatedContent(
            targetState = innerTabState,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "AiTabTransition"
        ) { activeIndex ->
            when (activeIndex) {
                0 -> ItineraryBuilderView(viewModel)
                1 -> AiChatView(viewModel)
            }
        }
    }
}

@Composable
fun ItineraryBuilderView(viewModel: YorkshireViewModel) {
    var days by remember { mutableStateOf(3f) }
    var selectedBudget by remember { mutableStateOf("Moderate") }
    var selectedInterest by remember { mutableStateOf("Heritage") }
    var selectedTransport by remember { mutableStateOf("Rail") }

    val aiState by viewModel.itineraryAiState.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Configure Itinerary Parameters",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Set your custom preferences below. Our AI will map a logical daily route.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
        }

        // Days Slider
        Column {
            Text(
                text = "Number of Days: ${days.toInt()}",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Slider(
                value = days,
                onValueChange = { days = it },
                valueRange = 1f..7f,
                steps = 5,
                colors = SliderDefaults.colors(
                    activeTrackColor = MaterialTheme.colorScheme.primary,
                    thumbColor = MaterialTheme.colorScheme.primary
                )
            )
        }

        // Budget Segment
        Column {
            Text(text = "Travel Budget Mode", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Economy", "Moderate", "Luxury").forEach { budget ->
                    val isSelected = selectedBudget == budget
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedBudget = budget },
                        label = { Text(budget) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Core Interests Segment
        Column {
            Text(text = "Core Interests", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Heritage", "Outdoors", "Railways", "Food").forEach { interest ->
                    val isSelected = selectedInterest == interest
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedInterest = interest },
                        label = { Text(interest) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Transport Mode Segment
        Column {
            Text(text = "Primary Transport", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Rail", "Car", "Walk").forEach { transport ->
                    val isSelected = selectedTransport == transport
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTransport = transport },
                        label = { Text(transport) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Build Button
        Button(
            onClick = {
                viewModel.buildItinerary(days.toInt(), selectedBudget, selectedInterest, selectedTransport)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("generate_itinerary_button"),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Icon(Icons.Filled.AutoAwesome, null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Generate Itinerary with AI", fontWeight = FontWeight.Bold)
        }

        // Result Container
        when (val state = aiState) {
            is AiState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "AI is drafting your custom route across the county...",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
            is AiState.Success -> {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Your AI Yorkshire Itinerary",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 16.sp
                            )
                            Icon(Icons.Filled.Verified, "AI Verification", tint = Color(0xFFC5A059))
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        MarkdownRenderer(text = state.response)
                    }
                }
            }
            is AiState.Error -> {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Error building itinerary: ${state.message}",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(16.dp),
                        fontSize = 12.sp
                    )
                }
            }
            else -> {
                // Idle state, show historic listings if any
                val itineraries by viewModel.itineraries.collectAsState()
                if (itineraries.isNotEmpty()) {
                    Text(
                        text = "Previously Saved Journeys",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    itineraries.forEach { itn ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${itn.days}-Day ${itn.interests} Tour",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "Budget: ${itn.budget}",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                MarkdownRenderer(text = itn.resultHtml)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiChatView(viewModel: YorkshireViewModel) {
    val chats by viewModel.chatHistory.collectAsState()
    val chatState by viewModel.chatAiState.collectAsState()
    var inputQuery by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Chat List Panel
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chats) { chat ->
                val isAi = chat.first == "AI Guide"
                ChatBalloon(isAi = isAi, name = chat.first, message = chat.second)
            }
            if (chatState is AiState.Loading) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI Guide is crafting a reply...", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }

        // Quick suggested queries row
        val suggestionChips = listOf(
            "Romantic Whitby",
            "Show steam trains",
            "Best Sunday Roast"
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(suggestionChips) { chipText ->
                SuggestionChip(
                    onClick = {
                        val fullPrompt = when (chipText) {
                            "Romantic Whitby" -> "Plan me a romantic weekend near Whitby."
                            "Show steam trains" -> "Show steam trains running tomorrow."
                            "Best Sunday Roast" -> "Best Sunday roast within 20 miles."
                            else -> chipText
                        }
                        viewModel.sendChatQuery(fullPrompt)
                        coroutineScope.launch {
                            listState.animateScrollToItem(chats.size)
                        }
                    },
                    label = { Text(chipText, fontSize = 11.sp) }
                )
            }
        }

        // Input bottom bar
        Surface(
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .navigationBarsPadding(), // Support Notch/Gesture Navigation spacing!
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = inputQuery,
                    onValueChange = { inputQuery = it },
                    placeholder = { Text("Ask Yorkshire Guide...", fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_chat_input_field"),
                    shape = RoundedCornerShape(24.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    maxLines = 2
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (inputQuery.isNotBlank()) {
                            viewModel.sendChatQuery(inputQuery)
                            inputQuery = ""
                            coroutineScope.launch {
                                listState.animateScrollToItem(chats.size)
                            }
                        }
                    },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                        .size(44.dp)
                        .testTag("ai_chat_send_button")
                ) {
                    Icon(Icons.Filled.Send, contentDescription = "Send", tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun ChatBalloon(isAi: Boolean, name: String, message: String) {
    val alignment = if (isAi) Alignment.Start else Alignment.End
    val balloonColor = if (isAi) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary
    val textColor = if (isAi) MaterialTheme.colorScheme.onSurfaceVariant else Color.White

    Column(horizontalAlignment = alignment, modifier = Modifier.fillMaxWidth()) {
        Text(
            text = name,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .background(
                    color = balloonColor,
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isAi) 0.dp else 16.dp,
                        bottomEnd = if (isAi) 16.dp else 0.dp
                    )
                )
                .padding(12.dp)
        ) {
            MarkdownRenderer(text = message, defaultColor = textColor)
        }
    }
}

// Custom Markdown bullet/headers parser to render beautiful readable texts without using external md libraries
@Composable
fun MarkdownRenderer(text: String, defaultColor: Color = Color.Unspecified) {
    val lines = text.split("\n")
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        lines.forEach { line ->
            val cleanLine = line.trim()
            when {
                cleanLine.startsWith("###") -> {
                    Text(
                        text = cleanLine.replace("###", "").trim(),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                    )
                }
                cleanLine.startsWith("##") -> {
                    Text(
                        text = cleanLine.replace("##", "").trim(),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                    )
                }
                cleanLine.startsWith("-") || cleanLine.startsWith("*") -> {
                    val rawText = cleanLine.substring(1).trim()
                    Row(modifier = Modifier.padding(start = 8.dp)) {
                        Text("•  ", fontSize = 12.sp, color = defaultColor)
                        BoldFormatText(rawText = rawText, defaultColor = defaultColor)
                    }
                }
                else -> {
                    BoldFormatText(rawText = cleanLine, defaultColor = defaultColor)
                }
            }
        }
    }
}

// Parses **Text** blocks to produce bold highlights inside lines
@Composable
fun BoldFormatText(rawText: String, defaultColor: Color) {
    if (rawText.contains("**")) {
        val parts = rawText.split("**")
        Row(modifier = Modifier.fillMaxWidth()) {
            parts.forEachIndexed { index, part ->
                val isBold = index % 2 != 0
                Text(
                    text = part,
                    fontSize = 12.sp,
                    fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
                    color = defaultColor
                )
            }
        }
    } else {
        Text(
            text = rawText,
            fontSize = 12.sp,
            color = defaultColor
        )
    }
}
