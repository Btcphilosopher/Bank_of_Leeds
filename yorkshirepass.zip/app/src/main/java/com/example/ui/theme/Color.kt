package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Yorkshire Heritage Colors
val YorkshireBlue = Color(0xFF1D2B45)       // Deep Yorkshire Blue (#1D2B45)
val YorkshireBlueLight = Color(0xFF2C3E5F)  // Lighter Yorkshire Blue
val YorkshireStone = Color(0xFFE2E1DD)      // Yorkshire Stone Grey / Warm Grey (#E2E1DD)
val YorkshireStoneLight = Color(0xFFECEBE8) // Lighter Stone Grey
val YorkshireCream = Color(0xFFF9F7F2)      // Premium Cream Background (#F9F7F2)
val YorkshireBrass = Color(0xFFC5A059)      // Brass Accent (#C5A059)
val YorkshireGold = Color(0xFFD4AF37)       // Gold Highlight

// M3 Light Palette
val LightPrimary = YorkshireBlue
val LightOnPrimary = Color.White
val LightPrimaryContainer = YorkshireStone
val LightOnPrimaryContainer = YorkshireBlue
val LightSecondary = YorkshireBrass
val LightOnSecondary = Color.White
val LightTertiary = YorkshireBrass
val LightOnTertiary = Color.White
val LightBackground = YorkshireCream
val LightOnBackground = YorkshireBlue
val LightSurface = Color.White
val LightOnSurface = YorkshireBlue

// M3 Dark Palette
val DarkPrimary = YorkshireBrass
val DarkOnPrimary = Color.Black
val DarkPrimaryContainer = YorkshireBlue
val DarkOnPrimaryContainer = Color.White
val DarkSecondary = YorkshireStone
val DarkOnSecondary = YorkshireBlue
val DarkTertiary = YorkshireBrass
val DarkOnTertiary = Color.White
val DarkBackground = Color(0xFF121B2B) // Luxurious deep navy/midnight (#121B2B)
val DarkOnBackground = Color(0xFFF9F7F2)
val DarkSurface = Color(0xFF1D2B45)
val DarkOnSurface = Color(0xFFF9F7F2)

