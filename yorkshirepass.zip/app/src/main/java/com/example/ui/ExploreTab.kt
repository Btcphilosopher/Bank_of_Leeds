package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Attraction

@Composable
fun ExploreTab(viewModel: YorkshireViewModel) {
    val attractions = viewModel.attractions
    val selectedFilter = viewModel.selectedFilter
    
    // Map view vs List view toggle
    var isMapView by remember { mutableStateOf(true) }
    var selectedAttractionForDetail by remember { mutableStateOf<Attraction?>(null) }

    // Filter logic
    val filteredAttractions = attractions.filter { attraction ->
        when (selectedFilter) {
            "Heritage" -> attraction.category == "Heritage" || attraction.category == "Museums"
            "Outdoors" -> attraction.category == "Nature" || attraction.category == "Coast"
            "Food" -> attraction.category == "Food & Drink"
            "Rainy Day" -> attraction.category == "Museums" || attraction.category == "Food & Drink"
            "Dog Friendly" -> attraction.id in listOf("dales_park", "moors_park", "whitby_coast", "scarborough_beach", "bolton_abbey")
            "Family" -> attraction.category == "Theme Parks" || attraction.category == "Zoos" || attraction.category == "Museums"
            else -> true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Tab Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Explore Yorkshire",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.primary
            )
            
            // Map / List Toggle Button
            SingleChoiceSegmentedButtonRow {
                SegmentedButton(
                    selected = isMapView,
                    onClick = { isMapView = true },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Map", fontSize = 12.sp)
                    }
                }
                SegmentedButton(
                    selected = !isMapView,
                    onClick = { isMapView = false },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.List, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("List", fontSize = 12.sp)
                    }
                }
            }
        }

        // 2. Filters Row
        val filters = listOf("Heritage", "Outdoors", "Food", "Rainy Day", "Dog Friendly", "Family")
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filters) { filter ->
                FilterChip(
                    selected = selectedFilter == filter,
                    onClick = { viewModel.selectedFilter = filter },
                    label = { Text(filter) },
                    leadingIcon = {
                        val icon = when (filter) {
                            "Heritage" -> Icons.Filled.Castle
                            "Outdoors" -> Icons.Filled.Terrain
                            "Food" -> Icons.Filled.LocalDining
                            "Rainy Day" -> Icons.Filled.WbCloudy
                            "Dog Friendly" -> Icons.Filled.Pets
                            "Family" -> Icons.Filled.ChildCare
                            else -> Icons.Filled.Star
                        }
                        Icon(icon, null, modifier = Modifier.size(16.dp))
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3. Main Dynamic Content (Map vs List)
        AnimatedContent(
            targetState = isMapView,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            },
            label = "MapListToggle"
        ) { mapMode ->
            if (mapMode) {
                // INTERACTIVE MAP VIEW
                Column(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFFF1F5F9)) // Soft background representing land
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                    ) {
                        // Drawing static schematic lines of Yorkshire paths/rivers/rails on Canvas
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // River Ouse / Humber Estuary
                            val width = size.width
                            val height = size.height

                            // Draw a light blue curving river representing Humber / Ouse
                            val pathPoints = listOf(
                                Offset(width * 0.1f, height * 0.5f),
                                Offset(width * 0.35f, height * 0.45f),
                                Offset(width * 0.5f, height * 0.6f),
                                Offset(width * 0.75f, height * 0.75f),
                                Offset(width * 0.95f, height * 0.8f)
                            )
                            for (i in 0 until pathPoints.size - 1) {
                                drawLine(
                                    color = Color(0xFF90CAF9).copy(alpha = 0.5f),
                                    start = pathPoints[i],
                                    end = pathPoints[i + 1],
                                    strokeWidth = 6f
                                )
                            }
                        }

                        // Title watermark
                        Text(
                            text = "YORKSHIRE COUNTY DIRECTORY MAP",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(12.dp)
                        )

                        // Interactive Map Pins
                        // 1. York Minster (Center-Left)
                        MapPin(
                            name = "York Hub",
                            sub = "Minster & Railway Museum",
                            icon = Icons.Filled.Church,
                            color = Color(0xFF0B2240),
                            modifier = Modifier.align(Alignment.Center),
                            onClick = { selectedAttractionForDetail = attractions.firstOrNull { it.id == "york_minster" } }
                        )

                        // 2. Whitby Abbey (Top-Right Coast)
                        MapPin(
                            name = "Whitby (Coast)",
                            sub = "Abbey & Harbour",
                            icon = Icons.Filled.Sailing,
                            color = Color(0xFF1E3D6B),
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 40.dp, end = 50.dp),
                            onClick = { selectedAttractionForDetail = attractions.firstOrNull { it.id == "whitby_abbey" } }
                        )

                        // 3. Castle Howard (Center-East)
                        MapPin(
                            name = "Castle Howard",
                            sub = "Stately Palace",
                            icon = Icons.Filled.Castle,
                            color = Color(0xFFC5A059),
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 40.dp, top = 20.dp),
                            onClick = { selectedAttractionForDetail = attractions.firstOrNull { it.id == "castle_howard" } }
                        )

                        // 4. Yorkshire Dales (Center-West)
                        MapPin(
                            name = "Dales National Park",
                            sub = "Nature & Walks",
                            icon = Icons.Filled.Terrain,
                            color = Color(0xFF15803D),
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(start = 30.dp, bottom = 60.dp),
                            onClick = { selectedAttractionForDetail = attractions.firstOrNull { it.id == "dales_park" } }
                        )

                        // 5. Black Sheep Brewery (North-West)
                        MapPin(
                            name = "Masham",
                            sub = "Breweries & Farms",
                            icon = Icons.Filled.LocalBar,
                            color = Color(0xFFB45309),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(start = 60.dp, top = 50.dp),
                            onClick = { selectedAttractionForDetail = attractions.firstOrNull { it.id == "black_sheep" } }
                        )
                        
                        // Compass rose decal
                        Text(
                            text = "N\n▲\nS",
                            textAlign = TextAlign.Center,
                            color = Color.Gray,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(16.dp)
                        )
                    }

                    // Attractions in selected filter list under map
                    Text(
                        text = "Attractions on Map ($selectedFilter)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .padding(bottom = 12.dp)
                    ) {
                        items(filteredAttractions) { attraction ->
                            MapAttractionCard(attraction) {
                                selectedAttractionForDetail = attraction
                            }
                        }
                    }
                }
            } else {
                // LIST VIEW
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (filteredAttractions.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Filled.SearchOff,
                                        contentDescription = null,
                                        modifier = Modifier.size(48.dp),
                                        tint = Color.Gray
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No matching Yorkshire attractions found.")
                                }
                            }
                        }
                    } else {
                        items(filteredAttractions) { attraction ->
                            ListAttractionRow(attraction) {
                                selectedAttractionForDetail = attraction
                            }
                        }
                    }
                }
            }
        }
    }

    // --- Attraction Detail Alert Dialog ---
    selectedAttractionForDetail?.let { attraction ->
        AlertDialog(
            onDismissRequest = { selectedAttractionForDetail = null },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.bookAttraction(attraction)
                        selectedAttractionForDetail = null
                    },
                    modifier = Modifier.testTag("book_with_pass_button")
                ) {
                    Text("Book Ticket")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedAttractionForDetail = null }) {
                    Text("Cancel")
                }
            },
            title = {
                Text(
                    text = attraction.title,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = MaterialTheme.colorScheme.primary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = attraction.category.uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = attraction.description,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f)
                    )
                    
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LocationOn, "Location", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(attraction.location, fontSize = 12.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Schedule, "Hours", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(attraction.hours, fontSize = 12.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.ConfirmationNumber, "Price", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(attraction.entryPrice, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Info, "Pass Benefit", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (viewModel.selectedTier == "Premium" || viewModel.selectedTier == "Gold") {
                                    "Pass benefit: Included! Book instantly to receive your digital QR pass."
                                } else {
                                    "Pass benefit: Included with Premium or Gold tiers. Upgrade to save £!"
                                },
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun MapPin(
    name: String,
    sub: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .shadow(4.dp, CircleShape)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = name,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
        Surface(
            color = Color.White.copy(alpha = 0.95f),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.padding(top = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(name, fontWeight = FontWeight.Bold, fontSize = 9.sp, color = Color.Black)
                Text(sub, fontSize = 8.sp, color = Color.DarkGray)
            }
        }
    }
}

@Composable
fun MapAttractionCard(attraction: Attraction, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(180.dp)
            .fillMaxHeight()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(
                    text = attraction.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = attraction.location,
                    fontSize = 10.sp,
                    color = Color.Gray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(attraction.entryPrice, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Icon(Icons.Filled.ArrowForward, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
            }
        }
    }
}

@Composable
fun ListAttractionRow(attraction: Attraction, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                val icon = when (attraction.icon) {
                    "church" -> Icons.Filled.Church
                    "castle" -> Icons.Filled.Castle
                    "train" -> Icons.Filled.Train
                    "local_cafe" -> Icons.Filled.LocalCafe
                    "local_bar" -> Icons.Filled.LocalBar
                    "landscape" -> Icons.Filled.Landscape
                    "pets" -> Icons.Filled.Pets
                    else -> Icons.Filled.Place
                }
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = attraction.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = attraction.entryPrice,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = attraction.description,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocationOn, null, tint = Color.Gray, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(attraction.location, fontSize = 10.sp, color = Color.Gray)
                }
            }
        }
    }
}
