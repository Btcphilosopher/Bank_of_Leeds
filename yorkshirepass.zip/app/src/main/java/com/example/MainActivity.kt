package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: YorkshireViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                var selectedTab by remember { mutableStateOf(0) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "THE OFFICIAL DIGITAL PASS",
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp,
                                        letterSpacing = 1.5.sp
                                    )
                                    Row {
                                        Text(
                                            text = "Yorkshire",
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 22.sp,
                                            fontFamily = FontFamily.Serif
                                        )
                                        Text(
                                            text = "Pass",
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Normal,
                                            fontStyle = FontStyle.Italic,
                                            fontSize = 22.sp,
                                            fontFamily = FontFamily.Serif
                                        )
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background
                            ),
                            actions = {
                                if (viewModel.offlineModeEnabled) {
                                    Icon(
                                        imageVector = Icons.Filled.WifiOff,
                                        contentDescription = "Offline Mode Active",
                                        tint = Color(0xFFDC2626),
                                        modifier = Modifier.padding(end = 16.dp)
                                    )
                                }
                            }
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            val navItems = listOf(
                                Triple("Home", Icons.Filled.Home, 0),
                                Triple("Explore", Icons.Filled.Explore, 1),
                                Triple("Bookings", Icons.Filled.ConfirmationNumber, 2),
                                Triple("Pass", Icons.Filled.CardMembership, 3),
                                Triple("AI Guide", Icons.Filled.AutoAwesome, 4),
                                Triple("Settings", Icons.Filled.Settings, 5)
                            )

                            navItems.forEach { (label, icon, index) ->
                                NavigationBarItem(
                                    selected = selectedTab == index,
                                    onClick = { selectedTab = index },
                                    icon = { Icon(icon, contentDescription = label) },
                                    label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = selectedTab,
                            transitionSpec = {
                                if (targetState > initialState) {
                                    slideInHorizontally { width -> width } + fadeIn() togetherWith
                                            slideOutHorizontally { width -> -width } + fadeOut()
                                } else {
                                    slideInHorizontally { width -> -width } + fadeIn() togetherWith
                                            slideOutHorizontally { width -> width } + fadeOut()
                                }
                            },
                            label = "TabTransition"
                        ) { tabIndex ->
                            when (tabIndex) {
                                0 -> HomeTab(viewModel = viewModel, onNavigateToTab = { selectedTab = it })
                                1 -> ExploreTab(viewModel = viewModel)
                                2 -> BookingsTab(viewModel = viewModel)
                                3 -> PassTab(viewModel = viewModel)
                                4 -> AiGuideTab(viewModel = viewModel)
                                5 -> ProfileTab(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
