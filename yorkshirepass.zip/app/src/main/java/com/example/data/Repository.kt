package com.example.data

import android.content.Context
import android.util.Log
import com.example.api.Content
import com.example.api.GenerateContentRequest
import com.example.api.Part
import com.example.api.RetrofitClient
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class YorkshireRepository(context: Context) {
    private val database = YorkshireDatabase.getDatabase(context)
    private val bookingDao = database.bookingDao()
    private val stampDao = database.stampDao()
    private val badgeDao = database.badgeDao()
    private val itineraryDao = database.itineraryDao()

    val allBookings: Flow<List<Booking>> = bookingDao.getAllBookings()
    val allStamps: Flow<List<Stamp>> = stampDao.getAllStamps()
    val allBadges: Flow<List<Badge>> = badgeDao.getAllBadges()
    val allItineraries: Flow<List<Itinerary>> = itineraryDao.getAllItineraries()

    // 1. Static Attractions Dataset
    val attractions = listOf(
        // Heritage
        Attraction("york_minster", "York Minster", "Heritage", "One of the world's most magnificent cathedrals, crafted in stone with exquisite stained glass.", "York YO1 7HH", "£18.00 (Free with Premium)", "9:30 AM - 4:30 PM", "church", "img_app_icon"),
        Attraction("castle_howard", "Castle Howard", "Heritage", "Stately 18th-century home set in breathtaking gardens, lakes, and temples.", "Malton YO60 7DA", "£22.00 (Free with Premium)", "10:00 AM - 5:00 PM", "castle", "img_yorkshire_hero"),
        Attraction("fountains_abbey", "Fountains Abbey & Studley Royal", "Heritage", "UNESCO World Heritage site with atmospheric ruins of a 12th-century monastery and Georgian water gardens.", "Ripon HG4 3DY", "£17.00 (Free with Premium)", "10:00 AM - 4:30 PM", "temple_hindu", "img_yorkshire_hero"),
        Attraction("whitby_abbey", "Whitby Abbey", "Heritage", "Dramatic cliffside ruins that inspired Bram Stoker's Dracula, overlooking the historic seaport.", "Whitby YO22 4DP", "£12.00 (Free with Premium)", "10:00 AM - 5:00 PM", "museum", "img_app_icon"),
        Attraction("bolton_abbey", "Bolton Abbey", "Heritage", "Ruins of an Augustinian Priory in the heart of the Dales, set in over 30,000 acres of beautiful countryside.", "Skipton BD23 6EX", "£15.00 (per car)", "9:00 AM - 6:00 PM", "landscape", "img_yorkshire_hero"),

        // Railways
        Attraction("nym_railway", "North Yorkshire Moors Railway", "Railways", "Steam heritage railway running through the stunning North York Moors National Park.", "Pickering YO18 7AJ", "£45.00 (20% off Premium)", "9:00 AM - 5:30 PM", "train", "img_app_icon"),
        Attraction("worth_valley_rail", "Keighley & Worth Valley Railway", "Railways", "A preserved standard-gauge line made famous by 'The Railway Children' movie.", "Haworth BD22 8NJ", "£25.00 (15% off Premium)", "10:00 AM - 4:00 PM", "train", "img_yorkshire_hero"),
        Attraction("middleton_rail", "Middleton Railway", "Railways", "The world's oldest continuously working railway, established in 1758.", "Leeds LS10 2JQ", "£8.00 (Free with Premium)", "11:00 AM - 4:00 PM", "train", "img_app_icon"),

        // Museums
        Attraction("nrm_museum", "National Railway Museum", "Museums", "Home of iconic locomotives including the Flying Scotsman and Mallard. Free entry, priority passes included.", "York YO26 4XJ", "Free Entry", "10:00 AM - 5:00 PM", "train", "img_yorkshire_hero"),
        Attraction("jorvik_viking", "JORVIK Viking Centre", "Museums", "Travel back in time to ride through the reconstructed streets of Viking-age York.", "York YO1 9WT", "£15.00 (Free with Premium)", "10:00 AM - 6:00 PM", "explore", "img_app_icon"),
        Attraction("yorkshire_museum", "Yorkshire Museum", "Museums", "Houses fantastic collections of Roman, Viking, and medieval treasure.", "York YO1 7FR", "£9.00 (Free with Premium)", "11:00 AM - 4:00 PM", "museum", "img_yorkshire_hero"),

        // Nature
        Attraction("dales_park", "Yorkshire Dales National Park", "Nature", "Sweeping valleys, stone-built villages, drystone walls, and limestone scenery.", "Bainbridge DL8 3EL", "Free Entry", "Open 24/7", "landscape", "img_yorkshire_hero"),
        Attraction("moors_park", "North York Moors National Park", "Nature", "One of the largest expanses of heather moorland in the UK, meeting dramatic coastlines.", "Helmsley YO62 5BP", "Free Entry", "Open 24/7", "forest", "img_yorkshire_hero"),
        Attraction("spurn_point", "Spurn Point Nature Reserve", "Nature", "Yorkshire's very own lands end, a unique three-mile curving peninsula of shifting sand.", "Kilnsea HU12 0UH", "Free Entry", "9:00 AM - 5:00 PM", "waves", "img_yorkshire_hero"),

        // Food & Drink
        Attraction("bettys_harrogate", "Bettys Café Tea Rooms", "Food & Drink", "The legendary institution serving magnificent Afternoon Tea and Swiss-Yorkshire culinary delights.", "Harrogate HG1 2QL", "A la carte", "9:00 AM - 5:30 PM", "local_cafe", "img_app_icon"),
        Attraction("york_gin", "York Gin Distillery", "Food & Drink", "Premium craft distillery producing world-class gins, inspired by York's 2,000-year history.", "York YO1 8AS", "Tastings £20.00", "10:00 AM - 5:30 PM", "local_bar", "img_app_icon"),
        Attraction("black_sheep", "Black Sheep Brewery", "Food & Drink", "Independent Yorkshire brewery. Enjoy a tour of the brewhouse and fresh cask ales.", "Masham HG4 4EN", "Tours £12.50", "11:00 AM - 11:00 PM", "local_bar", "img_app_icon"),

        // Theme Parks / Zoos
        Attraction("flamingo_land", "Flamingo Land Resort", "Theme Parks", "Theme park and award-winning zoo featuring white-knuckle rollercoasters and exotic wildlife.", "Kirby Misperton YO17 6UX", "£49.00 (10% off Premium)", "10:00 AM - 5:00 PM", "toys", "img_yorkshire_hero"),
        Attraction("wildlife_park", "Yorkshire Wildlife Park", "Zoos", "Dynamic walk-through safari park featuring polar bears, lions, and tigers.", "Doncaster DN9 3HQ", "£24.00 (10% off Premium)", "10:00 AM - 6:00 PM", "pets", "img_yorkshire_hero"),

        // Coast
        Attraction("whitby_coast", "Whitby Harbour & Town", "Coast", "Charming coastal town famed for historic abbey, jet jewelry, and world-class fish and chips.", "Whitby YO21 1YN", "Free Entry", "Open 24/7", "sailing", "img_app_icon"),
        Attraction("scarborough_beach", "Scarborough South Bay", "Coast", "Classic Victorian seaside resort with sandy beaches, a historic castle, and busy harbor.", "Scarborough YO11 1NT", "Free Entry", "Open 24/7", "beach_access", "img_yorkshire_hero")
    )

    // 2. Static Events Dataset
    val events = listOf(
        YorkshireEvent("event_1", "Malton Food Lovers Festival", "August 29-31, 2026", "Malton Town Centre", "Food Festival", "The 'Glastonbury of Food' returns with local artisans, celebrity chefs, and street food."),
        YorkshireEvent("event_2", "NYMR Autumn Steam Gala", "September 25-28, 2026", "Pickering Station", "Steam Gala", "A celebration of steam power with visiting locomotives and intensive timetables."),
        YorkshireEvent("event_3", "Yorkshire County Cricket Fixture", "August 12, 2026", "Headingley, Leeds", "Cricket", "Yorkshire vs Lancashire - the historic roses clash in the County Championship."),
        YorkshireEvent("event_4", "Great Yorkshire Show", "July 14-17, 2026", "Harrogate Showground", "Agricultural Show", "The premier agricultural event showcase with over 130,000 visitors, livestock, and machinery."),
        YorkshireEvent("event_5", "Yorkshire Wolds Walking Festival", "October 10-18, 2026", "Pocklington", "Walking Festival", "Dozens of guided walks traversing the picturesque chalk hills and quiet valleys.")
    )

    // 3. Prepopulate Stamps and Badges
    suspend fun populateInitialDataIfNeeded() {
        val stampCount = stampDao.getAllStamps().firstOrNull()?.size ?: 0
        if (stampCount == 0) {
            val initialStamps = listOf(
                // Food Passport Stamps
                Stamp("stamp_bettys", "Bettys Café Tea Rooms", "Food", "Cafe", "Harrogate", false, ""),
                Stamp("stamp_york_gin", "York Gin Distillery", "Food", "Brewery", "York", false, ""),
                Stamp("stamp_black_sheep", "Black Sheep Brewery", "Food", "Brewery", "Masham", false, ""),
                Stamp("stamp_shambles", "Shambles Food Market", "Food", "Pub", "York", false, ""),
                Stamp("stamp_black_bull", "The Black Bull Inn", "Food", "Pub", "Moulton", false, ""),

                // Yorkshire Passport Stamps
                Stamp("stamp_minster", "York Minster", "Passport", "Cathedral", "York", false, ""),
                Stamp("stamp_whitby_abbey", "Whitby Abbey", "Passport", "Castle", "Whitby", false, ""),
                Stamp("stamp_nymr", "North Yorkshire Moors Railway", "Passport", "Heritage Rail", "Pickering", false, ""),
                Stamp("stamp_dales", "Yorkshire Dales Park", "Passport", "National Park", "Grassington", false, ""),
                Stamp("stamp_scarborough", "Scarborough South Bay", "Passport", "Coastal Town", "Scarborough", false, "")
            )
            stampDao.insertStamps(initialStamps)
        }

        val badgeCount = badgeDao.getAllBadges().firstOrNull()?.size ?: 0
        if (badgeCount == 0) {
            val initialBadges = listOf(
                Badge("badge_explorer", "Yorkshire Explorer", "Start your grand tour by activating the YorkshirePass.", true, getCurrentDateString()),
                Badge("badge_railway", "Railway Conductor", "Unlock all heritage railway stamps.", false, ""),
                Badge("badge_noble", "Lord / Lady of the Castle", "Visit historic castles and magnificent abbeys.", false, ""),
                Badge("badge_foodie", "Yorkshire Foodie", "Collect 3 different digital stamps from local food & drink partners.", false, ""),
                Badge("badge_marathon", "Grand Tourer", "Collect 5 or more digital stamps overall in Yorkshire.", false, "")
            )
            badgeDao.insertBadges(initialBadges)
        }
    }

    private fun getCurrentDateString(): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.UK)
        return sdf.format(Date())
    }

    // 4. Booking Database Operations
    suspend fun addBooking(title: String, type: String, dateTime: String, qrData: String, price: String, location: String) {
        val ref = "YP-" + (100000..999999).random()
        val booking = Booking(
            title = title,
            type = type,
            dateTime = dateTime,
            qrData = qrData,
            price = price,
            location = location,
            bookingRef = ref
        )
        bookingDao.insertBooking(booking)
    }

    suspend fun deleteBooking(bookingId: Int) {
        bookingDao.deleteBookingById(bookingId)
    }

    // 5. Passport & Stamp Operations
    suspend fun collectStamp(id: String) {
        val date = getCurrentDateString()
        stampDao.unlockStamp(id, date)

        // Evaluate achievement triggers
        evaluateBadgeAchievements()
    }

    private suspend fun evaluateBadgeAchievements() {
        val date = getCurrentDateString()
        val stamps = stampDao.getAllStamps().firstOrNull() ?: emptyList()
        val unlockedCount = stamps.count { it.isUnlocked }

        // Foodie badge: 3 food stamps unlocked
        val foodUnlocked = stamps.count { it.category == "Food" && it.isUnlocked }
        if (foodUnlocked >= 3) {
            badgeDao.unlockBadge("badge_foodie", date)
        }

        // Castle badge: Whitby Abbey stamp unlocked
        val castleUnlocked = stamps.firstOrNull { it.id == "stamp_whitby_abbey" }?.isUnlocked == true
        if (castleUnlocked) {
            badgeDao.unlockBadge("badge_noble", date)
        }

        // Railway badge: NYMR stamp unlocked
        val railUnlocked = stamps.firstOrNull { it.id == "stamp_nymr" }?.isUnlocked == true
        if (railUnlocked) {
            badgeDao.unlockBadge("badge_railway", date)
        }

        // Grand Tourer: 5 stamps overall
        if (unlockedCount >= 5) {
            badgeDao.unlockBadge("badge_marathon", date)
        }
    }

    suspend fun resetPassport() {
        stampDao.resetAllStamps()
        badgeDao.resetAllBadges()
        // Reactivate baseline badge
        badgeDao.unlockBadge("badge_explorer", getCurrentDateString())
    }

    // 6. Itinerary Operations
    suspend fun buildAndSaveItinerary(days: Int, budget: String, interests: String, transportMode: String): String {
        val prompt = """
            You are the official YorkshirePass AI Smart Itinerary Assistant. 
            Generate a concise and beautiful daily itinerary for a trip to Yorkshire, UK based on these parameters:
            - Number of days: $days
            - Budget: $budget
            - Interests: $interests
            - Mode of transport: $transportMode

            Format the output with clear headers and bullet points. Use standard Markdown. Focus on real places in Yorkshire (York, Whitby, Haworth, Harrogate, Castle Howard, Yorkshire Dales, etc.). Include times like 9:00 AM, 12:00 PM, 3:00 PM, 6:00 PM. Keep it practical and engaging. Add a concluding tip about using YorkshirePass to save money.
        """.trimIndent()

        val resultText = callGeminiApi(prompt)

        val itinerary = Itinerary(
            days = days,
            budget = budget,
            interests = interests,
            transportMode = transportMode,
            resultHtml = resultText
        )
        itineraryDao.insertItinerary(itinerary)
        return resultText
    }

    // 7. General Gemini Assistant
    suspend fun askYorkshireGuide(query: String): String {
        val systemInstruction = """
            You are the premium 'AI Yorkshire Guide' inside YorkshirePass. You are friendly, expert, and proud of Yorkshire heritage. 
            Answer travel questions about Yorkshire concisely, focusing on attractions, dining, heritage rail, walks, coast, and local culture. 
            Keep answers readable and split into direct bullet points or brief paragraphs. 
            If the query is unrelated to Yorkshire, politely bring it back to Yorkshire!
        """.trimIndent()

        val prompt = "$systemInstruction\n\nUser Question: $query"
        return callGeminiApi(prompt)
    }

    private suspend fun callGeminiApi(prompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w("YorkshireRepository", "Gemini API key is missing or is placeholder. Using simulated offline guide.")
            return@withContext getOfflineResponse(prompt)
        }

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt))))
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "I was unable to retrieve information at this moment. Please check your connection."
        } catch (e: Exception) {
            Log.e("YorkshireRepository", "Gemini API call failed", e)
            "Error contacting AI Assistant. Generating local simulated recommendation instead:\n\n" + getOfflineResponse(prompt)
        }
    }

    private fun getOfflineResponse(prompt: String): String {
        return when {
            prompt.contains("romantic", ignoreCase = true) -> {
                """
                🏰 **Simulated Romantic Weekend in Whitby**
                
                - **Day 1**: Arrive in Whitby, stay at a boutique hotel on the West Cliff. Climb the 199 Steps to Whitby Abbey ruins at sunset, and dine on gourmet seafood in the historic harbor.
                - **Day 2**: Take a scenic steam journey on the North Yorkshire Moors Railway to Pickering. Enjoy Afternoon Tea on the Pullman service, and stroll around the quaint market town.
                - **Day 3**: Drive to Robin Hood's Bay for a quiet walk along the sweeping sandy beaches and explore smuggler alleyways.
                
                *Tip: Use YorkshirePass Gold for fast-track abbey entry andNYMR Pullman upgrades!*
                """.trimIndent()
            }
            prompt.contains("steam", ignoreCase = true) || prompt.contains("train", ignoreCase = true) -> {
                """
                🚂 **Heritage Steam Trains Guide**
                
                - **North Yorkshire Moors Railway**: Hourly steam services between Pickering and Whitby. Beautiful historic coaches.
                - **Keighley & Worth Valley Railway**: Authentic branch line steam engines in Haworth (Brontë Country).
                - **Middleton Railway (Leeds)**: Perfect family day out to experience industrial steam history.
                
                *Present your YorkshirePass QR code at tickets booths for exclusive 15-20% discounts on daily rover tickets!*
                """.trimIndent()
            }
            prompt.contains("roast", ignoreCase = true) || prompt.contains("Sunday", ignoreCase = true) -> {
                """
                🥧 **Best Traditional Sunday Roasts**
                
                - **The Black Bull (Moulton)**: Renowned for tender Yorkshire beef, gigantic puddings, and rich homemade onion gravy.
                - **The Star Inn (Harome)**: Exquisite thatched inn serving local game and perfectly crisp roast potatoes.
                - **The Shambles Tavern (York)**: Excellent traditional pub roast in the heart of medieval York.
                
                *Pass Members collect double digital stamps and receive a free Yorkshire Pudding appetizer at participating local inns!*
                """.trimIndent()
            }
            prompt.contains("itinerary", ignoreCase = true) || prompt.contains("Generate a concise", ignoreCase = true) -> {
                val days = if (prompt.contains("days: 1", ignoreCase = true)) "1-Day" else "Multi-Day"
                """
                🗺️ **Your Yorkshire Custom Itinerary ($days Explorer)**
                
                - **09:00 AM - York Minster**: Witness the glorious early light filtering through the great East Window. Climb the central tower.
                - **11:30 AM - Shambles & Food Market**: Stroll York's medieval alleys, grab a warm roast pork bap with apple sauce.
                - **01:30 PM - National Railway Museum**: Marvel at the Mallard and Bullet Trains in the world's greatest railway exhibit.
                - **04:00 PM - Castle Howard**: A short taxi/drive to explore the iconic baroque palace grounds and fountain lake.
                - **07:00 PM - Ghost Walk of York**: End your spectacular day with local folk stories in historic cobblestone lanes.
                
                *Savings with YorkshirePass: Free admission to York Minster, Castle Howard, and priority entrance to the Viking Centre saves you over £55 per person!*
                """.trimIndent()
            }
            else -> {
                """
                👋 **Welcome to Yorkshire - Your Digital Companion**
                
                I'm ready to assist you on your grand tour across England's historic county. Ask me about:
                - Cascading dales and historic abbeys.
                - Dynamic steam locomotives in action.
                - Best fish & chips spots along the coast.
                
                *Offline Notice: This is an offline helper response. Configure a valid Gemini API Key in AI Studio to activate full real-time AI capabilities!*
                """.trimIndent()
            }
        }
    }
}
