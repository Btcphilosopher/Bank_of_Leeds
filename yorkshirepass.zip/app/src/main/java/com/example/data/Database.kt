package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY dateTime ASC")
    fun getAllBookings(): Flow<List<Booking>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: Booking)

    @Delete
    suspend fun deleteBooking(booking: Booking)

    @Query("DELETE FROM bookings WHERE id = :id")
    suspend fun deleteBookingById(id: Int)
}

@Dao
interface StampDao {
    @Query("SELECT * FROM stamps")
    fun getAllStamps(): Flow<List<Stamp>>

    @Query("SELECT * FROM stamps WHERE category = :category")
    fun getStampsByCategory(category: String): Flow<List<Stamp>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStamp(stamp: Stamp)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStamps(stamps: List<Stamp>)

    @Query("UPDATE stamps SET isUnlocked = 1, dateUnlocked = :date, count = count + 1 WHERE id = :id")
    suspend fun unlockStamp(id: String, date: String)

    @Query("UPDATE stamps SET isUnlocked = 0, dateUnlocked = '', count = 0")
    suspend fun resetAllStamps()
}

@Dao
interface BadgeDao {
    @Query("SELECT * FROM badges")
    fun getAllBadges(): Flow<List<Badge>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBadges(badges: List<Badge>)

    @Query("UPDATE badges SET isUnlocked = 1, dateUnlocked = :date WHERE id = :id")
    suspend fun unlockBadge(id: String, date: String)

    @Query("UPDATE badges SET isUnlocked = 0, dateUnlocked = ''")
    suspend fun resetAllBadges()
}

@Dao
interface ItineraryDao {
    @Query("SELECT * FROM itineraries ORDER BY timestamp DESC")
    fun getAllItineraries(): Flow<List<Itinerary>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItinerary(itinerary: Itinerary)

    @Query("DELETE FROM itineraries WHERE id = :id")
    suspend fun deleteItinerary(id: Int)
}

@Database(entities = [Booking::class, Stamp::class, Badge::class, Itinerary::class], version = 1, exportSchema = false)
abstract class YorkshireDatabase : RoomDatabase() {
    abstract fun bookingDao(): BookingDao
    abstract fun stampDao(): StampDao
    abstract fun badgeDao(): BadgeDao
    abstract fun itineraryDao(): ItineraryDao

    companion object {
        @Volatile
        private var INSTANCE: YorkshireDatabase? = null

        fun getDatabase(context: Context): YorkshireDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    YorkshireDatabase::class.java,
                    "yorkshire_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
