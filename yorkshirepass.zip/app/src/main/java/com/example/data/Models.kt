package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val type: String, // "Attraction", "Rail", "Hotel", "Restaurant"
    val dateTime: String,
    val qrData: String,
    val price: String,
    val location: String,
    val bookingRef: String,
    val isPassed: Boolean = false
)

@Entity(tableName = "stamps")
data class Stamp(
    @PrimaryKey val id: String, // Unique identifier e.g. "betty_tea_room"
    val title: String,
    val category: String, // "Food" (pubs, breweries, cafés) or "Passport" (cathedrals, railways, castles, national parks, coastal towns)
    val subCategory: String, // e.g. "Cathedral", "Heritage Rail", "Castle", "National Park", "Coastal Town", "Pub", "Brewery", "Cafe", "Restaurant"
    val location: String,
    val isUnlocked: Boolean = false,
    val dateUnlocked: String = "",
    val count: Int = 0
)

@Entity(tableName = "badges")
data class Badge(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val isUnlocked: Boolean = false,
    val dateUnlocked: String = ""
)

@Entity(tableName = "itineraries")
data class Itinerary(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val days: Int,
    val budget: String,
    val interests: String,
    val transportMode: String,
    val resultHtml: String, // Cached content from Gemini AI
    val timestamp: Long = System.currentTimeMillis()
)

// Standard Attractions data model
data class Attraction(
    val id: String,
    val title: String,
    val category: String, // "Heritage", "Railways", "Museums", "Nature", "Theme Parks", "Sports", "Food & Drink", "Coast"
    val description: String,
    val location: String,
    val entryPrice: String,
    val hours: String,
    val icon: String, // String identifier for icons
    val imageResName: String = "" // Optional custom image
)

// Standard Event data model
data class YorkshireEvent(
    val id: String,
    val title: String,
    val date: String,
    val location: String,
    val category: String, // "Food Festival", "Steam Gala", "Cricket", "Agricultural Show", "Walking Festival"
    val description: String
)
