package com.example.api

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val TAG = "GeminiService"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun escapeJsonString(str: String): String {
        return str.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }

    suspend fun generateResponse(prompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        // If apiKey is empty, placeholder, or blank, fallback to local intelligent answers
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "GEMINI_API_KEY") {
            Log.d(TAG, "Using smart local fallback assistant")
            return@withContext getLocalFallbackResponse(prompt)
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        val systemInstruction = "You are the official Flamingo Land Resort AI Assistant. " +
                "You help guests navigating the theme park, zoo, and holiday resort. " +
                "Be extremely polite, warm, and helpful, incorporating a delightful Yorkshire personality " +
                "(using gentle Yorkshire slang like 'Ey up!', 'love', 'champ', or 'grand' occasionally but keeping it premium and professional). " +
                "Answer questions about rides (Velocity, Kumali, Hero, Mumbo Jumbo), the Zoo (tigers, lions, giraffes, conservation), " +
                "dining, stays, and tickets. Keep answers clear, beautifully spaced, and concise (under 4-5 sentences)."

        val jsonPayload = """
        {
          "contents": [
            {
              "parts": [
                {
                  "text": "${escapeJsonString(prompt)}"
                }
              ]
            }
          ],
          "systemInstruction": {
            "parts": [
              {
                "text": "${escapeJsonString(systemInstruction)}"
              }
            ]
          }
        }
        """.trimIndent()

        val requestBody = jsonPayload.toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string()
                if (!response.isSuccessful || bodyString == null) {
                    Log.e(TAG, "Gemini API error code ${response.code}: $bodyString")
                    return@withContext "Ey up, love! I'm having a little trouble connecting to the network right now. But don't worry, the sun is shining over Flamingo Land! How can I help you locally?"
                }

                val jsonResponse = JSONObject(bodyString)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val contentObj = candidates.getJSONObject(0).optJSONObject("content")
                    val parts = contentObj?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "No response text")
                    }
                }
                "Sorry, I couldn't understand that response. Can I help you with something else?"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during Gemini API call", e)
            getLocalFallbackResponse(prompt)
        }
    }

    private fun getLocalFallbackResponse(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("coffee") || lower.contains("cafe") || lower.contains("tea") -> {
                "Ey up! The nearest coffee is at the **Muddy Duck Café** near the Zoo entrance, or you can get a grand brew at the **Yorkshire Tea Room** in the Plaza. They serve brilliant hot drinks and scones, love!"
            }
            lower.contains("shortest queue") || lower.contains("wait time") || lower.contains("rides") && lower.contains("short") -> {
                "Right now, **Velocity** has a 15-minute wait, and **Mumbo Jumbo** is at just 10 minutes! The shortest queue in the resort is **Splash Battle** at a mere 5 minutes. Perfect time for a splash!"
            }
            lower.contains("giraffe") || lower.contains("giraffes") -> {
                "You can find our majestic Rothschild's Giraffes in the **African Plains** section of the Zoo, right next to the Rhinos and Zebras. Keeper talks are daily at 13:45, champ!"
            }
            lower.contains("tiger") || lower.contains("tigers") -> {
                "Our magnificent Sumatran Tigers are located in the tiger territory near the Zoo entrance. Feeding time is at 11:00 AM daily, love. It's a grand sight to see!"
            }
            lower.contains("plan") || lower.contains("itinerary") || lower.contains("afternoon") -> {
                "Here is a grand afternoon plan I've put together for you:\n\n" +
                        "• **13:00** — See the incredible **Sea Lion Show**\n" +
                        "• **13:45** — Catch the Giraffe Keeper Talk\n" +
                        "• **14:30** — Coaster thrills on **Kumali** (30 min queue)\n" +
                        "• **15:30** — Relaxing journey on the **Zoo Railway**\n" +
                        "• **16:30** — Grab a sweet treat at **Yorkshire Fudge Kitchen**"
            }
            lower.contains("ticket") || lower.contains("price") || lower.contains("book") -> {
                "You can view and book day tickets or VIP passes in the **Tickets** tab right here in the app! If you're staying at our Holiday Village, check-in is managed under the **Stay** tab."
            }
            lower.contains("hello") || lower.contains("hi") || lower.contains("hey") -> {
                "Ey up, love! Welcome to Flamingo Land Resort. I'm your AI Resort Assistant. Ask me anything about our rides, animals, hotels, or where to grab some grand Yorkshire food!"
            }
            else -> {
                "That's a grand question, love! In Flamingo Land Resort, we have over 100 rides, a world-class conservation Zoo, and beautiful holiday homes. For specific live queries, please make sure your Gemini API Key is entered in the Secrets panel, or ask me about rides, giraffes, coffee, or afternoon plans!"
            }
        }
    }
}
