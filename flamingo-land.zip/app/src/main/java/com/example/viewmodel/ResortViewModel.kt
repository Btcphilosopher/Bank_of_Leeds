package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiService
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

// Enum for Navigation Tabs
enum class ResortTab(val title: String, val icon: String) {
    HOME("Home", "🏠"),
    RIDES("Rides", "🎢"),
    ZOO("Zoo", "🦁"),
    MAP("Map", "🗺"),
    TICKETS("Tickets", "🎟"),
    FOOD("Food", "🍔"),
    STAY("Stay", "🏨"),
    PROFILE("Profile", "👤")
}

// Data models for Static Data
data class Ride(
    val id: String,
    val name: String,
    val category: String,
    val intensity: String, // "High", "Medium", "Low"
    val minHeight: Double, // in meters
    val description: String,
    val waitTimeMinutes: Int,
    val avgWaitMinutes: Int,
    val status: String, // "Open", "Closed", "Maintenance", "Weather Delay"
    val imageResName: String,
    val coordinates: Pair<Float, Float>,
    val bestTimeToRide: String,
    val isVirtualQueueBooked: Boolean = false
)

data class Animal(
    val id: String,
    val name: String,
    val scientificName: String,
    val conservationStatus: String, // "Critically Endangered", "Endangered", "Vulnerable", "Least Concern"
    val feedingTime: String,
    val description: String,
    val funFact: String,
    val habitat: String,
    val coordinates: Pair<Float, Float>,
    val isPassportCollected: Boolean = false
)

data class Restaurant(
    val id: String,
    val name: String,
    val category: String, // "Pizza", "Burgers", "Yorkshire Food", "Ice Cream", "Coffee"
    val tags: List<String>, // "Vegetarian", "Vegan", "Gluten Free", "Kids Meals"
    val description: String,
    val menuItems: List<MenuItem>,
    val coordinates: Pair<Float, Float>,
    val openingHours: String = "10:00 - 18:00"
)

data class MenuItem(
    val name: String,
    val price: Double,
    val description: String,
    val tags: List<String>
)

data class HotelStay(
    val bookingReference: String,
    val hotelName: String, // "The Flamingo Hotel", "Holiday Village Lodge", "Riverside Cottages"
    val roomNumber: String,
    val checkInDate: String,
    val checkOutDate: String,
    val isCheckedIn: Boolean,
    val breakfastBooked: Boolean,
    val keyRequested: Boolean
)

class ResortViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = ResortRepository(db.resortDao())

    // UI States
    private val _currentTab = MutableStateFlow(ResortTab.HOME)
    val currentTab: StateFlow<ResortTab> = _currentTab.asStateFlow()

    // Persistent Room data mapped
    val tickets: StateFlow<List<TicketEntity>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<FavoriteEntity>> = repository.allFavorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val badges: StateFlow<List<BadgeEntity>> = repository.allBadges
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatMessages: StateFlow<List<ChatMessageEntity>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected item for Detail Screen / Bottom Sheet overlay
    private val _selectedRide = MutableStateFlow<Ride?>(null)
    val selectedRide: StateFlow<Ride?> = _selectedRide.asStateFlow()

    private val _selectedAnimal = MutableStateFlow<Animal?>(null)
    val selectedAnimal: StateFlow<Animal?> = _selectedAnimal.asStateFlow()

    private val _selectedRestaurant = MutableStateFlow<Restaurant?>(null)
    val selectedRestaurant: StateFlow<Restaurant?> = _selectedRestaurant.asStateFlow()

    // Interactive Map state
    private val _selectedMapLayer = MutableStateFlow("Theme Park")
    val selectedMapLayer: StateFlow<String> = _selectedMapLayer.asStateFlow()

    private val _mapSelectedPinId = MutableStateFlow<String?>(null)
    val mapSelectedPinId: StateFlow<String?> = _mapSelectedPinId.asStateFlow()

    // Food Order state
    private val _cart = MutableStateFlow<List<Pair<MenuItem, Int>>>(emptyList())
    val cart: StateFlow<List<Pair<MenuItem, Int>>> = _cart.asStateFlow()

    private val _activeFoodOrders = MutableStateFlow<List<String>>(emptyList())
    val activeFoodOrders: StateFlow<List<String>> = _activeFoodOrders.asStateFlow()

    // Hotel booking status (Simulated State)
    private val _hotelBooking = MutableStateFlow<HotelStay?>(
        HotelStay(
            bookingReference = "FL-HTL-88204",
            hotelName = "The Flamingo Resort Hotel",
            roomNumber = "Suite 304 (Flamingo Wing)",
            checkInDate = "Today",
            checkOutDate = "July 26, 2026",
            isCheckedIn = false,
            breakfastBooked = false,
            keyRequested = false
        )
    )
    val hotelBooking: StateFlow<HotelStay?> = _hotelBooking.asStateFlow()

    private val _housekeepingRequested = MutableStateFlow(false)
    val housekeepingRequested: StateFlow<Boolean> = _housekeepingRequested.asStateFlow()

    // Dynamic queue times / statuses
    private val _ridesList = MutableStateFlow<List<Ride>>(emptyList())
    val ridesList: StateFlow<List<Ride>> = _ridesList.asStateFlow()

    // Animal passport collection progress
    private val _collectedAnimalPassports = MutableStateFlow<Set<String>>(emptySet())
    val collectedAnimalPassports: StateFlow<Set<String>> = _collectedAnimalPassports.asStateFlow()

    // Personal Ride Planner State
    val thrillLevelPref = MutableStateFlow("High") // "High", "Medium", "Family"
    val heightPref = MutableStateFlow(1.40) // in meters
    val availableTimeHoursPref = MutableStateFlow(4) // hours
    val groupSizePref = MutableStateFlow(4)

    private val _plannedItinerary = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val plannedItinerary: StateFlow<List<Pair<String, String>>> = _plannedItinerary.asStateFlow()

    // Chat assistant loading state
    private val _chatLoading = MutableStateFlow(false)
    val chatLoading: StateFlow<Boolean> = _chatLoading.asStateFlow()

    // Static Data Lists
    val staticRides = listOf(
        Ride("r_velocity", "Velocity", "Extreme Coaster", "High", 1.37, "The UK's only motor-bike launch coaster. Accelerates from 0-60mph in just 2.8 seconds, flying over Yorkshire hills!", 25, 45, "Open", "resort_hero", Pair(30f, 40f), "Before 11:00 AM"),
        Ride("r_kumali", "Kumali", "Suspended Coaster", "High", 1.37, "An intense, sensational inverted looping coaster featuring standard cobra rolls, loops, and zero-g heartline spins.", 35, 50, "Open", "resort_hero", Pair(40f, 45f), "Around 1:30 PM"),
        Ride("r_mumbo_jumbo", "Mumbo Jumbo", "Steep Drop Coaster", "High", 1.22, "An incredible coaster that held the world record for the steepest drop at 112 degrees. Features extreme high-g turns.", 15, 30, "Open", "resort_hero", Pair(35f, 35f), "After 4:00 PM"),
        Ride("r_hero", "Hero", "Flying Coaster", "High", 1.25, "Experience the sensation of flight! Suspended horizontally beneath the track, swooping and banking over the canyon.", 20, 35, "Open", "resort_hero", Pair(45f, 38f), "Between 12:00 and 1:00 PM"),
        Ride("r_lost_river", "Lost River Ride", "Water Ride", "Medium", 1.20, "Take a scenic jungle safari river journey that culminates in an immense splash-filled plunge into the plunge pool!", 40, 45, "Open", "resort_hero", Pair(55f, 65f), "During peak midday heat"),
        Ride("r_splash_battle", "Splash Battle", "Water Battle", "Low", 0.0, "An interactive splash ride where passengers shoot water cannons at spectators and other boats. Prepare to get soaked!", 5, 10, "Open", "resort_hero", Pair(50f, 55f), "Anytime"),
        Ride("r_dino_roller", "Dino Roller", "Junior Coaster", "Low", 0.90, "The perfect first coaster experience for little ones! A friendly dinosaur tracks a gentle winding course.", 5, 5, "Open", "resort_hero", Pair(25f, 30f), "Before 11:30 AM"),
        Ride("r_zoo_railway", "Zoo Railway", "Scenic Train", "Low", 0.0, "A delightful historic steam train running along a scenic loop, offering panoramic views of the animal exhibits.", 10, 15, "Open", "resort_hero", Pair(60f, 50f), "Just after lunch")
    )

    val staticAnimals = listOf(
        Animal("a_tiger", "Sumatran Tiger", "Panthera tigris sumatrae", "Critically Endangered", "11:00 AM", "Our beautiful tigers are part of crucial global breeding programs to save this majestic species. Only a few hundred remain in the wild.", "Tigers have striped skin, not just striped fur! No two tigers have the same pattern.", "Tiger Territory", Pair(65f, 25f)),
        Animal("a_giraffe", "Rothschild's Giraffe", "Giraffa camelopardalis rothschildi", "Vulnerable", "01:45 PM", "The tallest land mammal. Our elegant herd can be seen roaming the African plains paddock. Feeding is a beautiful interactive keeper highlight.", "A giraffe's tongue is blue-black and can be up to 45cm long to wrap around thorny acacia leaves!", "African Plains", Pair(75f, 30f)),
        Animal("a_lion", "African Lion", "Panthera leo", "Vulnerable", "12:00 PM", "Witness the pride of Flamingo Land! Our powerful lions are symbol of Yorkshire resort majesty, enjoying their spacious enclosure.", "Lions can sleep for up to 20 hours a day to conserve energy for hunting.", "Lion Reserve", Pair(70f, 35f)),
        Animal("a_penguin", "Humboldt Penguin", "Spheniscus humboldti", "Vulnerable", "01:00 PM", "A playful, aquatic colony. Watch them glide through the water and enjoy interactive feeding sessions with keepers.", "Penguins can hold their breath underwater for up to 15 minutes while diving for fish!", "Penguin Pool", Pair(60f, 20f)),
        Animal("a_sea_lion", "California Sea Lion", "Zalophus californianus", "Least Concern", "12:30 PM & 03:30 PM", "Incredibly intelligent and acrobatic! Check out the world-class live show demonstrating their agility, playfulness and keeper bond.", "Sea lions can swim at speeds of up to 25 miles per hour to evade predators like orcas.", "Sea Lion Cove", Pair(55f, 15f)),
        Animal("a_rhino", "Black Rhino", "Diceros bicornis", "Critically Endangered", "02:00 PM", "A heavily armor-plated, critically endangered prehistoric giant. Our conservation efforts support preserving wild rhino habitats.", "A group of rhinos is called a 'crash'! Their horn is made of keratin, the same material as hair and nails.", "Rhino Paddock", Pair(80f, 40f)),
        Animal("a_crane", "Crowned Crane", "Balearica regulorum", "Endangered", "03:00 PM", "Known for their golden crown of feathers and elegant mating dances. Beautiful species located near our quiet bird gardens.", "Crowned cranes are the only species of crane that can roost in trees due to a specialized hind toe.", "Bird Gardens", Pair(85f, 45f))
    )

    val staticRestaurants = listOf(
        Restaurant(
            id = "f_muddy_duck",
            name = "The Muddy Duck Café",
            category = "Burgers",
            tags = listOf("Kids Meals", "Gluten Free"),
            description = "Family favorite burger hub serving legendary charcoal-grilled beef burgers, golden fries, and premium shakes.",
            menuItems = listOf(
                MenuItem("Resort Classic Burger", 12.95, "Prime Yorkshire beef patty with fresh lettuce, cheddar cheese, and house sauce.", listOf("Classic")),
                MenuItem("Smoky BBQ Bacon Burger", 13.95, "Beef patty topped with crispy bacon, smoked cheddar, and sweet hickory BBQ sauce.", listOf("Smoky")),
                MenuItem("Golden Chicken Tenders", 8.95, "Crispy, hand-breaded chicken breast strips with garlic dip.", listOf("Kids Meals")),
                MenuItem("Loaded Salt & Pepper Fries", 6.50, "French fries tossed with sautéed bell peppers, onions, and spicy seasoning.", listOf("Gluten Free", "Vegetarian"))
            ),
            coordinates = Pair(38f, 52f)
        ),
        Restaurant(
            id = "f_tea_room",
            name = "Yorkshire Tea Room",
            category = "Yorkshire Food",
            tags = listOf("Vegetarian", "Kids Meals"),
            description = "Traditional Yorkshire cottage parlor serving authentic local breakfast, afternoon high teas, hot scones, and fresh brews.",
            menuItems = listOf(
                MenuItem("The Yorkshire High Tea", 15.50, "A tiered stand of finger sandwiches, fresh warm scones, clotted cream, jam, and local tea.", listOf("Classic")),
                MenuItem("Warm Scone with Jam & Cream", 4.95, "Baked fresh daily in our resort kitchen. Served with Yorkshire clotted cream.", listOf("Vegetarian")),
                MenuItem("Yorkshire Rarebit Toastie", 8.50, "Grated local cheddar melted with brown ale and mustard on sourdough toast.", listOf("Vegetarian")),
                MenuItem("Kids Mini Picnic Basket", 6.95, "Ham or cheese sandwich with fruit juice, crisps, and a chocolate treat.", listOf("Kids Meals"))
            ),
            coordinates = Pair(28f, 48f)
        ),
        Restaurant(
            id = "f_fabrizios",
            name = "Fabrizio's Pizzeria",
            category = "Pizza",
            tags = listOf("Vegetarian", "Vegan"),
            description = "Wood-fired pizzeria crafting artisanal hand-stretched Italian sourdough pizzas, rich pastas, and fresh salads.",
            menuItems = listOf(
                MenuItem("Classic Margherita Pizza", 11.50, "Sourdough crust with rich San Marzano tomato sauce, fresh buffalo mozzarella, and basil.", listOf("Vegetarian")),
                MenuItem("The Flaming Hot Volcano Pizza", 13.95, "Spicy pepperoni, local Yorkshire chorizo, fresh jalapeños, and hot honey drizzle.", listOf("Spicy")),
                MenuItem("Vegan Garden Feast Pizza", 12.50, "Dairy-free mozzarella, bell peppers, wild mushrooms, olives, and fresh arugula.", listOf("Vegan", "Vegetarian")),
                MenuItem("Creamy Pesto Penne", 10.95, "Penne pasta tossed in creamy basil pesto with pine nuts and cherry tomatoes.", listOf("Vegetarian"))
            ),
            coordinates = Pair(42f, 46f)
        ),
        Restaurant(
            id = "f_sweet_shack",
            name = "Flamingo Sweet Shack",
            category = "Ice Cream",
            tags = listOf("Kids Meals", "Vegetarian"),
            description = "The ultimate dessert parlor serving bubble waffles, chocolate-dipped waffle cones, and premium Yorkshire dairy ice cream.",
            menuItems = listOf(
                MenuItem("The Flamingo Pink Sundae", 7.95, "Three scoops of strawberry and vanilla ice cream, raspberry sauce, marshmallows, and pink sprinkles.", listOf("Kids Meals", "Vegetarian")),
                MenuItem("S'mores Bubble Waffle", 8.50, "Hot waffle loaded with toasted marshmallows, melted Belgian chocolate, and crushed biscuits.", listOf("Vegetarian")),
                MenuItem("Double Scoop Waffle Cone", 4.50, "Your choice of two scoops of delicious local dairy ice cream.", listOf("Vegetarian")),
                MenuItem("Hot Chocolate Deluxe", 3.95, "With whipped cream, mini marshmallows, and chocolate flake.", listOf("Vegetarian"))
            ),
            coordinates = Pair(48f, 58f)
        )
    )

    init {
        // Initialize dynamic rides list
        _ridesList.value = staticRides

        // Initialize databases and mock defaults
        viewModelScope.launch {
            repository.initializeDefaultBadgesIfNeeded()
            repository.initializeDefaultTicketsIfNeeded()
        }

        // Start background simulator for live queue times
        startLiveQueueTimesSimulation()
    }

    private fun startLiveQueueTimesSimulation() {
        viewModelScope.launch {
            while (true) {
                delay(15000) // update every 15 seconds
                _ridesList.value = _ridesList.value.map { ride ->
                    if (ride.status == "Open") {
                        val change = (-5..5).random()
                        val newWait = (ride.waitTimeMinutes + change).coerceIn(5, 75)
                        ride.copy(waitTimeMinutes = newWait)
                    } else {
                        ride
                    }
                }
            }
        }
    }

    // Setters
    fun setTab(tab: ResortTab) {
        _currentTab.value = tab
    }

    fun selectRide(ride: Ride?) {
        _selectedRide.value = ride
        _selectedAnimal.value = null
        _selectedRestaurant.value = null
    }

    fun selectAnimal(animal: Animal?) {
        _selectedAnimal.value = animal
        _selectedRide.value = null
        _selectedRestaurant.value = null
        
        // If an animal details page is viewed, unlock the Zoo Explorer badge!
        if (animal != null) {
            viewModelScope.launch {
                repository.unlockBadge("badge_zoo_explorer")
            }
        }
    }

    fun selectRestaurant(restaurant: Restaurant?) {
        _selectedRestaurant.value = restaurant
        _selectedRide.value = null
        _selectedAnimal.value = null
    }

    fun selectMapLayer(layer: String) {
        _selectedMapLayer.value = layer
        _mapSelectedPinId.value = null
    }

    fun selectMapPin(id: String?) {
        _mapSelectedPinId.value = id
        // Map pinning selection automatically syncs with detailed drawer selection!
        val rideMatch = staticRides.find { it.id == id }
        val animalMatch = staticAnimals.find { it.id == id }
        val restMatch = staticRestaurants.find { it.id == id }
        if (rideMatch != null) selectRide(rideMatch)
        else if (animalMatch != null) selectAnimal(animalMatch)
        else if (restMatch != null) selectRestaurant(restMatch)
    }

    // Ticket Store Actions
    fun buyTicket(type: String, title: String, details: String) {
        viewModelScope.launch {
            val qr = "FL-${type.take(3).uppercase()}-${(1000000..9999999).random()}"
            val newTicket = TicketEntity(
                type = type,
                title = title,
                date = "Tomorrow",
                qrCodeData = qr,
                details = details
            )
            repository.insertTicket(newTicket)
            
            // Check if VIP membership was unlocked
            if (type == "VIP Pass") {
                repository.unlockBadge("badge_vip")
            }
        }
    }

    // Favorite Attraction Actions
    fun toggleFavoriteState(attractionId: String, type: String) {
        viewModelScope.launch {
            repository.toggleFavorite(attractionId, type)
        }
    }

    // Virtual Queue booking
    fun bookVirtualQueue(rideId: String) {
        _ridesList.value = _ridesList.value.map { ride ->
            if (ride.id == rideId) {
                // Book a dynamic ticket representing the fastpass slot!
                viewModelScope.launch {
                    val time = "14:30"
                    repository.insertTicket(
                        TicketEntity(
                            type = "FastPass",
                            title = "FastPass - ${ride.name}",
                            date = "Today @ $time",
                            qrCodeData = "FL-FAST-${(10000..99999).random()}",
                            details = "Group of ${groupSizePref.value} • Show at entrance"
                        )
                    )
                    repository.unlockBadge("badge_coaster_master")
                }
                ride.copy(isVirtualQueueBooked = true)
            } else {
                ride
            }
        }
    }

    // Animal Passport collection
    fun collectPassport(animalId: String) {
        val current = _collectedAnimalPassports.value.toMutableSet()
        if (current.add(animalId)) {
            _collectedAnimalPassports.value = current
            // Automatically unlock wildlife badge!
            viewModelScope.launch {
                repository.unlockBadge("badge_zoo_explorer")
            }
        }
    }

    // Personal Ride Planner Algorithm
    fun generatePersonalItinerary() {
        val thrill = thrillLevelPref.value
        val height = heightPref.value
        val timeLimit = availableTimeHoursPref.value

        // Filter and score eligible rides
        val eligibleRides = staticRides.filter { ride ->
            ride.minHeight <= height && (thrill == "High" || ride.intensity != "High")
        }.shuffled()

        val timeline = mutableListOf<Pair<String, String>>()
        var currentMinutes = 9 * 60 + 30 // Start at 09:30 AM
        
        var addedRides = 0
        var addedZoo = false
        var addedLunch = false

        for (ride in eligibleRides) {
            val totalNeeded = ride.waitTimeMinutes + 20 // 20 mins to walk & ride
            if (currentMinutes + totalNeeded > (9 * 60 + 30) + (timeLimit * 60)) break

            val timeStr = String.format("%02d:%02d", currentMinutes / 60, currentMinutes % 60)
            timeline.add(Pair(timeStr, "Ride: ${ride.name} (${ride.waitTimeMinutes} min wait)"))
            currentMinutes += totalNeeded

            addedRides++

            // Inject lunch after 12:00
            if (!addedLunch && currentMinutes >= 12 * 60) {
                val lunchTimeStr = String.format("%02d:%02d", currentMinutes / 60, currentMinutes % 60)
                timeline.add(Pair(lunchTimeStr, "Lunch: Fabrizio's Pizzeria or Muddy Duck"))
                currentMinutes += 45 // 45 mins lunch
                addedLunch = true
            }

            // Inject Zoo visit in between
            if (!addedZoo && addedRides >= 2) {
                val zooTimeStr = String.format("%02d:%02d", currentMinutes / 60, currentMinutes % 60)
                timeline.add(Pair(zooTimeStr, "Zoo Explorer: Majestic Rothschild's Giraffes & Tigers"))
                currentMinutes += 60 // 1 hour zoo
                addedZoo = true
            }
        }

        // Fill remaining time if any
        if (timeline.isEmpty()) {
            timeline.add(Pair("09:30", "Gentle walk to Zoo & Muddy Duck Café"))
            timeline.add(Pair("11:30", "Scenic steam train on Zoo Railway"))
        }

        _plannedItinerary.value = timeline
    }

    // Food Order Actions
    fun addToCart(item: MenuItem) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.first.name == item.name }
        if (index != -1) {
            val count = current[index].second
            current[index] = Pair(item, count + 1)
        } else {
            current.add(Pair(item, 1))
        }
        _cart.value = current
    }

    fun removeFromCart(item: MenuItem) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.first.name == item.name }
        if (index != -1) {
            val count = current[index].second
            if (count > 1) {
                current[index] = Pair(item, count - 1)
            } else {
                current.removeAt(index)
            }
        }
        _cart.value = current
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun checkoutFood() {
        if (_cart.value.isEmpty()) return
        val orderId = "FL-FOOD-${(10000..99999).random()}"
        val total = _cart.value.sumOf { it.first.price * it.second }
        val namesStr = _cart.value.joinToString { "${it.second}x ${it.first.name}" }

        viewModelScope.launch {
            // Book a dynamic receipt/order inside the ticket system
            repository.insertTicket(
                TicketEntity(
                    type = "Food Order",
                    title = "Table Order: $orderId",
                    date = "Today (Preparing)",
                    qrCodeData = orderId,
                    details = "$namesStr • Total: £${String.format("%.2f", total)}"
                )
            )
            repository.unlockBadge("badge_yorkshire_foodie")
        }

        _activeFoodOrders.value = _activeFoodOrders.value + orderId
        _cart.value = emptyList()
    }

    // Stay / Hotel Actions
    fun checkInHotel() {
        val current = _hotelBooking.value ?: return
        _hotelBooking.value = current.copy(isCheckedIn = true)
        
        viewModelScope.launch {
            repository.unlockBadge("badge_resort_resident")
            repository.insertTicket(
                TicketEntity(
                    type = "Hotel Reservation",
                    title = "Hotel Room Key: ${current.roomNumber}",
                    date = "Today (Active)",
                    qrCodeData = "FL-KEY-${current.bookingReference}",
                    details = "Tap phone on your door handle to unlock room"
                )
            )
        }
    }

    fun requestHousekeeping() {
        _housekeepingRequested.value = true
        viewModelScope.launch {
            repository.unlockBadge("badge_resort_resident")
            delay(5000) // reset request after 5 seconds
            _housekeepingRequested.value = false
        }
    }

    fun bookBreakfast() {
        val current = _hotelBooking.value ?: return
        _hotelBooking.value = current.copy(breakfastBooked = true)
    }

    // Chat Actions (AI Assistant)
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return

        viewModelScope.launch {
            // Insert user message in database
            val userMsg = ChatMessageEntity(sender = "user", text = text)
            repository.insertMessage(userMsg)

            _chatLoading.value = true

            // Trigger AI Pioneer Badge
            repository.unlockBadge("badge_ai_pioneer")

            // Call Gemini
            val replyText = GeminiService.generateResponse(text)

            // Insert AI message in database
            val aiMsg = ChatMessageEntity(sender = "assistant", text = replyText)
            repository.insertMessage(aiMsg)

            _chatLoading.value = false
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChat()
        }
    }

    // loyalty score calculated reactively
    val loyaltyPoints: StateFlow<Int> = combine(tickets, badges, collectedAnimalPassports) { t, b, p ->
        var points = 100 // starting bonus
        points += t.size * 50 // 50 points per ticket booking/food order
        points += b.count { it.isUnlocked } * 200 // 200 points per challenge badge
        points += p.size * 30 // 30 points per animal passport stamp
        points
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 100)

    val membershipType: StateFlow<String> = loyaltyPoints.map { points ->
        when {
            points >= 1500 -> "VIP Pass"
            points >= 600 -> "Gold Pass"
            else -> "Free Member"
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Free Member")
}
