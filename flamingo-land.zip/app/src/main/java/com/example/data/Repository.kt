package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class ResortRepository(private val resortDao: ResortDao) {

    val allTickets: Flow<List<TicketEntity>> = resortDao.getAllTickets()
    val allFavorites: Flow<List<FavoriteEntity>> = resortDao.getAllFavorites()
    val allBadges: Flow<List<BadgeEntity>> = resortDao.getAllBadges()
    val allMessages: Flow<List<ChatMessageEntity>> = resortDao.getAllMessages()

    suspend fun insertTicket(ticket: TicketEntity) {
        resortDao.insertTicket(ticket)
    }

    suspend fun deleteTicket(ticket: TicketEntity) {
        resortDao.deleteTicket(ticket)
    }

    suspend fun toggleFavorite(attractionId: String, type: String) {
        val currentFavs = resortDao.getAllFavorites().first()
        val exists = currentFavs.any { it.attractionId == attractionId }
        if (exists) {
            resortDao.deleteFavoriteById(attractionId)
        } else {
            resortDao.insertFavorite(FavoriteEntity(attractionId = attractionId, type = type))
        }
    }

    suspend fun isFavorite(attractionId: String): Boolean {
        val currentFavs = resortDao.getAllFavorites().first()
        return currentFavs.any { it.attractionId == attractionId }
    }

    suspend fun unlockBadge(badgeId: String) {
        resortDao.updateBadgeUnlockStatus(badgeId, true, System.currentTimeMillis())
    }

    suspend fun insertMessage(message: ChatMessageEntity) {
        resortDao.insertMessage(message)
    }

    suspend fun clearChat() {
        resortDao.clearChat()
    }

    suspend fun initializeDefaultBadgesIfNeeded() {
        val currentBadges = resortDao.getAllBadges().first()
        if (currentBadges.isEmpty()) {
            val defaults = listOf(
                BadgeEntity(
                    badgeId = "badge_coaster_master",
                    title = "Coaster Connoisseur",
                    description = "Booked a FastPass for Velocity, Kumali, or Mumbo Jumbo",
                    iconName = "🎢",
                    isUnlocked = false
                ),
                BadgeEntity(
                    badgeId = "badge_zoo_explorer",
                    title = "Wildlife Champion",
                    description = "Discovered an animal's conservation status in the Zoo Explorer",
                    iconName = "🦁",
                    isUnlocked = false
                ),
                BadgeEntity(
                    badgeId = "badge_yorkshire_foodie",
                    title = "Yorkshire Foodie",
                    description = "Completed a mobile food order for delicious resort delicacies",
                    iconName = "🍔",
                    isUnlocked = false
                ),
                BadgeEntity(
                    badgeId = "badge_resort_resident",
                    title = "Resort Resident",
                    description = "Managed hotel reservations or requested housekeeping in the Stay hub",
                    iconName = "🏨",
                    isUnlocked = false
                ),
                BadgeEntity(
                    badgeId = "badge_ai_pioneer",
                    title = "AI Resort Pioneer",
                    description = "Asked the Flamingo AI Assistant a question about the park",
                    iconName = "✨",
                    isUnlocked = false
                )
            )
            for (badge in defaults) {
                resortDao.insertBadge(badge)
            }
        }
    }

    suspend fun initializeDefaultTicketsIfNeeded() {
        val currentTickets = resortDao.getAllTickets().first()
        if (currentTickets.isEmpty()) {
            resortDao.insertTicket(
                TicketEntity(
                    type = "Day Ticket",
                    title = "Standard 1-Day Pass",
                    date = "Today",
                    qrCodeData = "FL-DAY-TKT-5829104",
                    details = "Includes Theme Park & Zoo admission"
                )
            )
            resortDao.insertTicket(
                TicketEntity(
                    type = "VIP Pass",
                    title = "Gold Pass Membership",
                    date = "2026 Season",
                    qrCodeData = "FL-GOLD-MEM-7712940",
                    details = "Priority booking and 10% food discount"
                )
            )
        }
    }
}
