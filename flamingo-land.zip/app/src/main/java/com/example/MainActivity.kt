package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*
import com.example.viewmodel.*
import com.example.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: ResortViewModel = viewModel()
                ResortApp(viewModel)
            }
        }
    }
}

@Composable
fun ResortApp(viewModel: ResortViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Floating AI Assistant chat bottom sheet state
    var isChatAssistantOpen by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            // Standard M3 navigation bar with 5 primary ergonomic tabs
            NavigationBar(
                modifier = Modifier
                    .shadow(16.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .testTag("resort_bottom_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                val primaryTabs = listOf(
                    ResortTab.HOME,
                    ResortTab.RIDES,
                    ResortTab.ZOO,
                    ResortTab.MAP,
                    ResortTab.TICKETS
                )

                primaryTabs.forEach { tab ->
                    val selected = currentTab == tab
                    NavigationBarItem(
                        selected = selected,
                        onClick = { viewModel.setTab(tab) },
                        label = { Text(tab.title, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                        icon = {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = tab.icon,
                                    fontSize = if (selected) 24.sp else 20.sp,
                                    modifier = Modifier.animateContentSize()
                                )
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FlamingoPink,
                            selectedTextColor = FlamingoPink,
                            indicatorColor = Pink100,
                            unselectedIconColor = Slate500,
                            unselectedTextColor = Slate500
                        ),
                        modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
                    )
                }
            }
        },
        floatingActionButton = {
            // Floating AI Resort Assistant FAB
            ExtendedFloatingActionButton(
                onClick = { isChatAssistantOpen = true },
                icon = { Text("✨", fontSize = 20.sp) },
                text = { Text("Resort AI") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .padding(bottom = 12.dp)
                    .testTag("ai_assistant_fab")
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Crossfade transitions between different active screens
            Crossfade(targetState = currentTab, label = "ScreenTransition") { tab ->
                when (tab) {
                    ResortTab.HOME -> HomeScreen(viewModel, onSwitchTab = { viewModel.setTab(it) })
                    ResortTab.RIDES -> RidesScreen(viewModel)
                    ResortTab.ZOO -> ZooScreen(viewModel)
                    ResortTab.MAP -> MapScreen(viewModel)
                    ResortTab.TICKETS -> TicketsScreen(viewModel)
                    ResortTab.FOOD -> FoodScreen(viewModel)
                    ResortTab.STAY -> StayScreen(viewModel)
                    ResortTab.PROFILE -> ProfileScreen(viewModel)
                }
            }

            // Slide up / animated modal for the AI Resort Assistant
            AnimatedVisibility(
                visible = isChatAssistantOpen,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                AiAssistantPanel(
                    viewModel = viewModel,
                    onClose = { isChatAssistantOpen = false }
                )
            }
        }
    }
}

// ==========================================
// 1. HOME SCREEN COMPONENT
// ==========================================
@Composable
fun HomeScreen(viewModel: ResortViewModel, onSwitchTab: (ResortTab) -> Unit) {
    val tickets by viewModel.tickets.collectAsState()
    val loyaltyPoints by viewModel.loyaltyPoints.collectAsState()
    val membership by viewModel.membershipType.collectAsState()
    val badges by viewModel.badges.collectAsState()
    val activeBadgesCount = badges.count { it.isUnlocked }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("home_screen")
    ) {
        // 0. High Density Header Section from Design HTML
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "Resort Companion",
                        color = FlamingoPink,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row {
                        Text(
                            text = "Welcome back, ",
                            color = Slate900,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Explorer",
                            color = FlamingoPink,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Blue50)
                            .border(1.dp, Color(0xFFDBEAFE), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("☁️", fontSize = 18.sp)
                    }
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFCBD5E1))
                            .border(2.dp, Color.White, CircleShape)
                    )
                }
            }
        }

        // Hero Image Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(180.dp)
                    .clip(RoundedCornerShape(24.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.resort_hero),
                    contentDescription = "Flamingo Land Resort Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Premium scrim gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)),
                                startY = 150f
                            )
                        )
                )

                // Branding text overlapping the hero background
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Britain's Ultimate Resort Companion",
                        color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Welcome to Flamingo Land",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Theme Park • Zoo • Holiday Village • Resort",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // High Density Live Status Card (Gradient from pink to rose with pink glow shadow)
        item {
            Card(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .fillMaxWidth()
                    .height(120.dp),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Pink500, Rose600)
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "LIVE FROM THE PARK",
                            color = Color(0xFFFCE7F3),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Velocity is Ready! • 21°C",
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(100.dp))
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "WAIT: 15 MINS",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(4.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.5f))
                            )
                            Text(
                                text = "Shortest queue today • Enjoy a grand day out!",
                                color = Color(0xFFFCE7F3),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Member Wallet Mini Banner
        item {
            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSwitchTab(ResortTab.TICKETS) },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Slate100),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🎟️", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("My Tickets", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Slate900)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (tickets.isNotEmpty()) "${tickets.size} Active Passes" else "No active passes",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = FlamingoPink
                        )
                        Text("Tap to view wallet QR", style = MaterialTheme.typography.bodySmall, color = Slate500)
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSwitchTab(ResortTab.PROFILE) },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Slate100),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🏆", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Loyalty Rewards", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Slate900)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$loyaltyPoints Pts",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = ForestGreen
                        )
                        Text(membership, style = MaterialTheme.typography.bodySmall, color = Slate500, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Premium Quick Actions Resort Services Grid (Food, Stay, Profile)
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Explore Flamingo Land Resort",
                    fontWeight = FontWeight.ExtraBold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 12.dp),
                    color = ForestGreen
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HomeGridItem(
                        icon = "🍔",
                        title = "Order Food",
                        subtitle = "Mobile Ordering",
                        backgroundColor = Color(0xFFFFF2F4),
                        onClick = { onSwitchTab(ResortTab.FOOD) },
                        modifier = Modifier.weight(1f)
                    )
                    HomeGridItem(
                        icon = "🏨",
                        title = "Resort Stay",
                        subtitle = "Hotel & Key Hub",
                        backgroundColor = Color(0xFFECF7EF),
                        onClick = { onSwitchTab(ResortTab.STAY) },
                        modifier = Modifier.weight(1f)
                    )
                    HomeGridItem(
                        icon = "🛡️",
                        title = "Explorer Club",
                        subtitle = "$activeBadgesCount Badges Collected",
                        backgroundColor = Color(0xFFEEF6F9),
                        onClick = { onSwitchTab(ResortTab.PROFILE) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Horizontal scrolling News, Offers, and Events Feed
        item {
            Column(modifier = Modifier.padding(bottom = 24.dp)) {
                Text(
                    text = "Today's Highlights & Offers",
                    fontWeight = FontWeight.ExtraBold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
                    color = ForestGreen
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        NewsCard(
                            emoji = "🦁",
                            tag = "ANIMAL ENCOUNTER",
                            title = "Sumatran Tiger Keeper Talk",
                            desc = "Meet our keepers at 11:00 AM at Tiger Territory. Learn about Sumatran Tiger conservation.",
                            gradientStart = Color(0xFFFF9F43),
                            gradientEnd = Color(0xFFFF5252)
                        )
                    }
                    item {
                        NewsCard(
                            emoji = "🍔",
                            tag = "YORKSHIRE DELIGHTS",
                            title = "Yorkshire Tea Room Deal",
                            desc = "Get 15% off full High Tea towers when ordering ahead between 14:00 and 16:00 today!",
                            gradientStart = ForestGreen,
                            gradientEnd = Color(0xFF4CA664)
                        )
                    }
                    item {
                        NewsCard(
                            emoji = "🎪",
                            tag = "LIVE SHOW",
                            title = "Acrobatic Sea Lion Show",
                            desc = "Spectacular acrobatics and fun with sea lions at Sea Lion Cove at 12:30 PM & 03:30 PM.",
                            gradientStart = YorkshireSkyBlue,
                            gradientEnd = Color(0xFF1E6C8E)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeGridItem(
    icon: String,
    title: String,
    subtitle: String,
    backgroundColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(110.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Slate100),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(backgroundColor.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Text(icon, fontSize = 20.sp)
            }
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    color = Slate900,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    fontSize = 9.sp,
                    color = Slate500,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun NewsCard(
    emoji: String,
    tag: String,
    title: String,
    desc: String,
    gradientStart: Color,
    gradientEnd: Color
) {
    val badgeBg = if (gradientStart == ForestGreen) Green50 else if (gradientStart == YorkshireSkyBlue) Blue50 else Color(0xFFFFF1F2)
    val badgeText = if (gradientStart == ForestGreen) Green600 else if (gradientStart == YorkshireSkyBlue) Blue600 else FlamingoPink

    Card(
        modifier = Modifier
            .width(280.dp)
            .height(120.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Slate100),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(badgeBg),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = 22.sp)
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = title,
                        color = Slate900,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(100.dp))
                            .background(badgeBg)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (tag.contains("ANIMAL")) "TALK" else if (tag.contains("TEA")) "15% OFF" else "SHOW",
                            color = badgeText,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    color = Slate500,
                    fontSize = 11.sp,
                    lineHeight = 14.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ==========================================
// 2. RIDES SCREEN COMPONENT
// ==========================================
@Composable
fun RidesScreen(viewModel: ResortViewModel) {
    val rides by viewModel.ridesList.collectAsState()
    val selectedRide by viewModel.selectedRide.collectAsState()
    val plannedItinerary by viewModel.plannedItinerary.collectAsState()

    var isPlannerExpanded by remember { mutableStateOf(false) }

    val thrillLevelPref by viewModel.thrillLevelPref.collectAsState()
    val heightPref by viewModel.heightPref.collectAsState()
    val availableTimePref by viewModel.availableTimeHoursPref.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("rides_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Theme Park Attractions",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = ForestGreen
                )
                Text(
                    text = "Live queue forecasts & thrill planners",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        // Personal Ride Planner Tool Widget
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = WarmSand.copy(alpha = 0.3f)),
                border = BorderStroke(1.dp, ForestGreen.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isPlannerExpanded = !isPlannerExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("✨", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                            Column {
                                Text("AI Itinerary Builder", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = ForestGreen)
                                Text("Let AI build your perfect day plan", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }
                        IconButton(onClick = { isPlannerExpanded = !isPlannerExpanded }) {
                            Icon(
                                imageVector = if (isPlannerExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = "Expand Planner",
                                tint = ForestGreen
                            )
                        }
                    }

                    AnimatedVisibility(visible = isPlannerExpanded) {
                        Column(modifier = Modifier.padding(top = 16.dp)) {
                            Divider(color = ForestGreen.copy(alpha = 0.1f))
                            Spacer(modifier = Modifier.height(16.dp))

                            // Thrill preference
                            Text("Thrill Level Preference", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ForestGreen)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("High", "Medium", "Family").forEach { level ->
                                    val isSelected = thrillLevelPref == level
                                    Button(
                                        onClick = { viewModel.thrillLevelPref.value = level },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSelected) ForestGreen else Color.White,
                                            contentColor = if (isSelected) Color.White else ForestGreen
                                        ),
                                        border = BorderStroke(1.dp, ForestGreen),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(level, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Height Slider
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Minimum Height Limit", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ForestGreen)
                                Text("${String.format("%.2f", heightPref)} m", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FlamingoPink)
                            }
                            Slider(
                                value = heightPref.toFloat(),
                                onValueChange = { viewModel.heightPref.value = it.toDouble() },
                                valueRange = 0.8f..1.5f,
                                modifier = Modifier.padding(vertical = 4.dp),
                                colors = SliderDefaults.colors(thumbColor = FlamingoPink, activeTrackColor = FlamingoPink)
                            )

                            // Time Duration Selector
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Time Available in Resort", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ForestGreen)
                                Text("$availableTimePref Hours", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FlamingoPink)
                            }
                            Slider(
                                value = availableTimePref.toFloat(),
                                onValueChange = { viewModel.availableTimeHoursPref.value = it.toInt() },
                                valueRange = 2f..8f,
                                steps = 5,
                                modifier = Modifier.padding(vertical = 4.dp),
                                colors = SliderDefaults.colors(thumbColor = ForestGreen, activeTrackColor = ForestGreen)
                            )

                            Button(
                                onClick = { viewModel.generatePersonalItinerary() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 12.dp)
                                    .testTag("build_itinerary_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = FlamingoPink)
                            ) {
                                Text("Generate Itinerary", fontWeight = FontWeight.Bold)
                            }

                            // Output timeline if planned
                            if (plannedItinerary.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, ForestGreen.copy(alpha = 0.1f))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("Your AI Customized Itinerary", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ForestGreen)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        plannedItinerary.forEach { step ->
                                            Row(
                                                modifier = Modifier.padding(vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Card(
                                                    colors = CardDefaults.cardColors(containerColor = WarmSand),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(step.first, color = ForestGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(step.second, fontSize = 12.sp, color = Color.Black)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Heatmap info
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📊", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                        Text("Queue Forecast & Capacity Heatmap", fontWeight = FontWeight.Bold, color = ForestGreen, style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Peak resort crowd expected between 12:30 and 14:30. Best to visit rollercoasters during early morning or after 16:00.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
        }

        // Rides List
        items(rides) { ride ->
            RideCard(
                ride = ride,
                onClick = { viewModel.selectRide(ride) },
                onBookVirtualQueue = { viewModel.bookVirtualQueue(ride.id) }
            )
        }
    }

    // Detail Dialog drawer overlay
    if (selectedRide != null) {
        RideDetailDialog(ride = selectedRide!!, onClose = { viewModel.selectRide(null) }, onBookVirtualQueue = { viewModel.bookVirtualQueue(it) })
    }
}

@Composable
fun RideCard(ride: Ride, onClick: () -> Unit, onBookVirtualQueue: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("ride_card_${ride.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Slate100),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(WarmSand)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.resort_hero),
                    contentDescription = ride.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.2f))
                )
                Text("🎢", fontSize = 28.sp, modifier = Modifier.align(Alignment.Center))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(ride.name, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = Color.Black)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WarmSand),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(ride.intensity, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = ForestGreen, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    }
                }
                Text("Min Height: ${ride.minHeight}m", fontSize = 11.sp, color = Color.Gray)
                Text("Best time: ${ride.bestTimeToRide}", fontSize = 11.sp, color = ForestGreen, fontWeight = FontWeight.Medium)
            }

            // Waiting time Badge
            Column(horizontalAlignment = Alignment.End) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            ride.status != "Open" -> Color(0xFFECEFF1)
                            ride.waitTimeMinutes > 30 -> Color(0xFFFFEBEE)
                            else -> Color(0xFFE8F5E9)
                        }
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (ride.status == "Open") {
                            Text(
                                text = "${ride.waitTimeMinutes}",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (ride.waitTimeMinutes > 30) Color.Red else ForestGreen
                            )
                            Text("MIN WAIT", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        } else {
                            Text(
                                text = ride.status.uppercase(),
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = Color.DarkGray
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RideDetailDialog(ride: Ride, onClose: () -> Unit, onBookVirtualQueue: (String) -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(ride.name, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(WarmSand)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.resort_hero),
                        contentDescription = "Ride Detail Image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Text(ride.description, style = MaterialTheme.typography.bodyMedium, color = Color.DarkGray)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Average Wait Time", fontSize = 11.sp, color = Color.Gray)
                        Text("${ride.avgWaitMinutes} mins", fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                    Column {
                        Text("Accessibility", fontSize = 11.sp, color = Color.Gray)
                        Text("Wheelchair Ramp", fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                    Column {
                        Text("Location", fontSize = 11.sp, color = Color.Gray)
                        Text("Park East", fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }

                if (ride.isVirtualQueueBooked) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("✓ FastPass Slot Reserved (Check Tickets wallet)", color = ForestGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(12.dp), textAlign = TextAlign.Center)
                    }
                } else if (ride.status == "Open") {
                    Button(
                        onClick = { onBookVirtualQueue(ride.id) },
                        modifier = Modifier.fillMaxWidth().testTag("book_fastpass_dialog_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = FlamingoPink)
                    ) {
                        Text("Book Free FastPass Ticket", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) { Text("Close", fontWeight = FontWeight.Bold) }
        },
        shape = RoundedCornerShape(24.dp)
    )
}

// ==========================================
// 3. ZOO SCREEN COMPONENT
// ==========================================
@Composable
fun ZooScreen(viewModel: ResortViewModel) {
    val selectedAnimal by viewModel.selectedAnimal.collectAsState()
    val passportStamps by viewModel.collectedAnimalPassports.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("zoo_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Zoo Explorer Guide",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = ForestGreen
                )
                Text(
                    text = "Meet endangered species & collect animal stamps!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        // Live Zoo Feeding schedule
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ForestGreen.copy(alpha = 0.08f)),
                border = BorderStroke(1.dp, ForestGreen.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📢", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                        Text("Keeper Feeding Talks Schedule", fontWeight = FontWeight.ExtraBold, color = ForestGreen, style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    viewModel.staticAnimals.forEach { animal ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(animal.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(animal.feedingTime, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = FlamingoPink, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                    }
                }
            }
        }

        // List of Animals
        items(viewModel.staticAnimals) { animal ->
            val isStamped = passportStamps.contains(animal.id)
            AnimalCard(
                animal = animal,
                isStamped = isStamped,
                onClick = { viewModel.selectAnimal(animal) },
                onStampPassport = { viewModel.collectPassport(animal.id) }
            )
        }
    }

    if (selectedAnimal != null) {
        AnimalDetailDialog(
            animal = selectedAnimal!!,
            isStamped = passportStamps.contains(selectedAnimal!!.id),
            onClose = { viewModel.selectAnimal(null) },
            onStampPassport = { viewModel.collectPassport(it) }
        )
    }
}

@Composable
fun AnimalCard(animal: Animal, isStamped: Boolean, onClick: () -> Unit, onStampPassport: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("animal_card_${animal.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Slate100),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(WarmSand)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.resort_hero),
                    contentDescription = animal.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.2f))
                )
                Text("🦒", fontSize = 28.sp, modifier = Modifier.align(Alignment.Center))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(animal.name, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = Color.Black)
                Text(
                    text = animal.conservationStatus,
                    color = when (animal.conservationStatus) {
                        "Critically Endangered" -> Color.Red
                        "Endangered" -> Color(0xFFFF6F00)
                        "Vulnerable" -> Color(0xFFFBC02D)
                        else -> ForestGreen
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⏰ Feeding:", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(animal.feedingTime, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                }
            }

            // Collect stamp button
            Button(
                onClick = { onStampPassport() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isStamped) ForestGreen else FlamingoPink
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.testTag("stamp_${animal.id}")
            ) {
                Text(if (isStamped) "✓ Stamped" else "Stamp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AnimalDetailDialog(animal: Animal, isStamped: Boolean, onClose: () -> Unit, onStampPassport: (String) -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(animal.name, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(animal.scientificName, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(WarmSand)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.resort_hero),
                        contentDescription = "Animal Image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Text(animal.description, style = MaterialTheme.typography.bodyMedium, color = Color.DarkGray)

                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmSand.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("💡 Fun Conservation Fact", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ForestGreen)
                        Text(animal.funFact, fontSize = 11.sp, color = Color.Black)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Habitat", fontSize = 11.sp, color = Color.Gray)
                        Text(animal.habitat, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                    Column {
                        Text("Conservation", fontSize = 11.sp, color = Color.Gray)
                        Text(animal.conservationStatus, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }

                if (!isStamped) {
                    Button(
                        onClick = { onStampPassport(animal.id) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = FlamingoPink)
                    ) {
                        Text("Collect Animal Stamp badge", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("✓ Stamp Collected in Passport!", color = ForestGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(10.dp), textAlign = TextAlign.Center)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) { Text("Close", fontWeight = FontWeight.Bold) }
        },
        shape = RoundedCornerShape(24.dp)
    )
}

// ==========================================
// 4. MAP SCREEN COMPONENT (INTELLIGENT INTERACTIVE CANVAS)
// ==========================================
@Composable
fun MapScreen(viewModel: ResortViewModel) {
    val selectedLayer by viewModel.selectedMapLayer.collectAsState()
    val mapSelectedPinId by viewModel.mapSelectedPinId.collectAsState()

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("map_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "Interactive Resort Map",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = ForestGreen
            )
            Text(
                text = "Tap layers to view theme park, zoo, and dining pins",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray
            )
        }

        // Layer Selector Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = selectedLayer == "Theme Park",
                    onClick = { viewModel.selectMapLayer("Theme Park") },
                    label = { Text("🎢 Theme Park") }
                )
            }
            item {
                FilterChip(
                    selected = selectedLayer == "Zoo Guide",
                    onClick = { viewModel.selectMapLayer("Zoo Guide") },
                    label = { Text("🦒 Zoo Guide") }
                )
            }
            item {
                FilterChip(
                    selected = selectedLayer == "Dining & Food",
                    onClick = { viewModel.selectMapLayer("Dining & Food") },
                    label = { Text("🍔 Dining & Food") }
                )
            }
        }

        // Custom Vector Interactive Map Canvas Drawing
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .border(2.dp, ForestGreen.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                .background(Color(0xFFE8F5E9)) // Light Grass background
        ) {
            val pins = when (selectedLayer) {
                "Theme Park" -> viewModel.staticRides.map { Pair(it.id, it.name) }
                "Zoo Guide" -> viewModel.staticAnimals.map { Pair(it.id, it.name) }
                else -> viewModel.staticRestaurants.map { Pair(it.id, it.name) }
            }

            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(selectedLayer) {
                        detectTapGestures { offset ->
                            // Simple collision logic to match map tap to coordinates
                            val width = size.width
                            val height = size.height

                            var matchedId: String? = null
                            val matches = when (selectedLayer) {
                                "Theme Park" -> viewModel.staticRides.map { Pair(it.id, it.coordinates) }
                                "Zoo Guide" -> viewModel.staticAnimals.map { Pair(it.id, it.coordinates) }
                                else -> viewModel.staticRestaurants.map { Pair(it.id, it.coordinates) }
                            }

                            for (m in matches) {
                                val px = width * (m.second.first / 100f)
                                val py = height * (m.second.second / 100f)
                                val dist = Math.hypot((offset.x - px).toDouble(), (offset.y - py).toDouble())
                                if (dist < 40.0) { // 40 pixel tap radius
                                    matchedId = m.first
                                    break
                                }
                            }
                            viewModel.selectMapPin(matchedId)
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // Draw a beautiful winding blue river representing "The Lost River"
                val riverPath = Path().apply {
                    moveTo(0f, canvasHeight * 0.5f)
                    cubicTo(
                        canvasWidth * 0.3f, canvasHeight * 0.4f,
                        canvasWidth * 0.6f, canvasHeight * 0.8f,
                        canvasWidth, canvasHeight * 0.6f
                    )
                }
                drawPath(
                    path = riverPath,
                    color = Color(0xFF90CAF9),
                    style = Stroke(width = 24.dp.toPx(), cap = StrokeCap.Round)
                )

                // Draw Zoo Railway Tracks
                val trainPath = Path().apply {
                    moveTo(canvasWidth * 0.1f, canvasHeight * 0.1f)
                    lineTo(canvasWidth * 0.9f, canvasHeight * 0.1f)
                    lineTo(canvasWidth * 0.9f, canvasHeight * 0.9f)
                    lineTo(canvasWidth * 0.1f, canvasHeight * 0.9f)
                    close()
                }
                drawPath(
                    path = trainPath,
                    color = Color(0xFFB0BEC5),
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )

                // Draw static pins
                val pinsWithCoords = when (selectedLayer) {
                    "Theme Park" -> viewModel.staticRides.map { Triple(it.id, it.coordinates, "🎢") }
                    "Zoo Guide" -> viewModel.staticAnimals.map { Triple(it.id, it.coordinates, "🦁") }
                    else -> viewModel.staticRestaurants.map { Triple(it.id, it.coordinates, "🍔") }
                }

                for (pin in pinsWithCoords) {
                    val px = canvasWidth * (pin.second.first / 100f)
                    val py = canvasHeight * (pin.second.second / 100f)

                    val isSelected = mapSelectedPinId == pin.first

                    // Glow background for selected pin
                    if (isSelected) {
                        drawCircle(
                            color = FlamingoPink.copy(alpha = 0.4f),
                            radius = 24.dp.toPx(),
                            center = Offset(px, py)
                        )
                    }

                    // Standard pin marker circle
                    drawCircle(
                        color = if (isSelected) FlamingoPink else ForestGreen,
                        radius = 14.dp.toPx(),
                        center = Offset(px, py)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 11.dp.toPx(),
                        center = Offset(px, py)
                    )
                }
            }

            // Draw a floaty text guide helper so kids know they can click the canvas!
            Text(
                text = "👆 Tap the pins to discover live info",
                color = ForestGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(8.dp)
                    .background(Color.White.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )

            // Dynamic detail overlay card appearing on map pin selection
            if (mapSelectedPinId != null) {
                val ride = viewModel.staticRides.find { it.id == mapSelectedPinId }
                val animal = viewModel.staticAnimals.find { it.id == mapSelectedPinId }
                val restaurant = viewModel.staticRestaurants.find { it.id == mapSelectedPinId }

                Card(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                        .fillMaxWidth()
                        .shadow(12.dp, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = ride?.name ?: animal?.name ?: restaurant?.name ?: "",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.Black
                            )
                            Text(
                                text = ride?.category ?: animal?.conservationStatus ?: restaurant?.category ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🏃 Walking Time:", fontSize = 11.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("5-min walk", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ForestGreen)
                            }
                        }

                        IconButton(onClick = {
                            if (ride != null) viewModel.selectRide(ride)
                            else if (animal != null) viewModel.selectAnimal(animal)
                            else if (restaurant != null) viewModel.selectRestaurant(restaurant)
                        }) {
                            Icon(Icons.Default.Info, contentDescription = "More details", tint = FlamingoPink)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. TICKETS WALLET SCREEN COMPONENT
// ==========================================
@Composable
fun TicketsScreen(viewModel: ResortViewModel) {
    val tickets by viewModel.tickets.collectAsState()
    val loyaltyPoints by viewModel.loyaltyPoints.collectAsState()

    var activeWalletTab by remember { mutableStateOf("My Wallet") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("tickets_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Digital Tickets Wallet",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = ForestGreen
                )
                Text(
                    text = "Stored QR passes & resort bookings",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        // Sub-tabs: My Wallet, Buy Tickets
        item {
            TabRow(
                selectedTabIndex = if (activeWalletTab == "My Wallet") 0 else 1,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                indicator = {}
            ) {
                Tab(
                    selected = activeWalletTab == "My Wallet",
                    onClick = { activeWalletTab = "My Wallet" },
                    text = { Text("My Stored Passes (${tickets.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = activeWalletTab == "Buy Tickets",
                    onClick = { activeWalletTab = "Buy Tickets" },
                    text = { Text("Buy Passes", fontWeight = FontWeight.Bold) }
                )
            }
        }

        if (activeWalletTab == "My Wallet") {
            if (tickets.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🎟️", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No tickets in your wallet yet", fontWeight = FontWeight.Bold)
                        Text("Go to 'Buy Passes' or book stays/food to add tickets!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                }
            } else {
                items(tickets) { ticket ->
                    TicketItemCard(ticket = ticket)
                }
            }
        } else {
            // Buy passes store screen
            item {
                TicketStoreItem(
                    emoji = "🎫",
                    title = "Standard 1-Day Ticket",
                    desc = "Full admission to Flamingo Land Theme Park, Live Shows, and the Conservation Zoo for 1 guest.",
                    price = "£45.00",
                    rewardPoints = "+50 Loyalty Pts",
                    onBuy = {
                        viewModel.buyTicket(
                            "Day Ticket",
                            "Standard 1-Day Pass",
                            "Valid tomorrow for Theme Park & Zoo entrance."
                        )
                    }
                )
            }
            item {
                TicketStoreItem(
                    emoji = "🎖️",
                    title = "Gold Season Membership Pass",
                    desc = "Unlimited entry for 2026 season. Includes 10% food discounts, priority booking, and event invites.",
                    price = "£120.00",
                    rewardPoints = "+200 Loyalty Pts",
                    onBuy = {
                        viewModel.buyTicket(
                            "Season Pass",
                            "Gold Season Pass",
                            "Valid through Dec 2026 • 10% Food discounts active"
                        )
                    }
                )
            }
            item {
                TicketStoreItem(
                    emoji = "👑",
                    title = "VIP Resort Experience Pass",
                    desc = "The ultimate resort experience. Unlimited FastPasses for all rollercoasters, VIP lounges, and private animal feeding.",
                    price = "£180.00",
                    rewardPoints = "+400 Loyalty Pts",
                    onBuy = {
                        viewModel.buyTicket(
                            "VIP Pass",
                            "VIP Resort Pass",
                            "Unlimited FastPass • Private Zoo experience included"
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun TicketItemCard(ticket: TicketEntity) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .drawBehind {
                    // Perforated tear-off card design
                    val strokeWidth = 2.dp.toPx()
                    val y = size.height * 0.72f
                    var currentX = 0f
                    val dashLength = 8.dp.toPx()
                    val gapLength = 6.dp.toPx()
                    while (currentX < size.width) {
                        drawLine(
                            color = Color.LightGray,
                            start = Offset(currentX, y),
                            end = Offset(currentX + dashLength, y),
                            strokeWidth = strokeWidth
                        )
                        currentX += dashLength + gapLength
                    }
                }
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when (ticket.type) {
                            "Day Ticket" -> ForestGreen.copy(alpha = 0.1f)
                            "VIP Pass" -> Color(0xFFFFF8E1)
                            "FastPass" -> Color(0xFFFFEBEE)
                            else -> YorkshireSkyBlue.copy(alpha = 0.1f)
                        }
                    ),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = ticket.type.uppercase(),
                        fontWeight = FontWeight.ExtraBold,
                        color = when (ticket.type) {
                            "Day Ticket" -> ForestGreen
                            "VIP Pass" -> Color(0xFFFFB300)
                            "FastPass" -> Color.Red
                            else -> YorkshireSkyBlue
                        },
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Text(ticket.date, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(ticket.title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = Color.Black)
            Text(ticket.details, style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)

            Spacer(modifier = Modifier.height(30.dp)) // space for perforated line

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("PASS ID", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text(ticket.qrCodeData, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                }

                // QR Code Placeholder
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.size(52.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Drawing static vector simulation of QR block
                        Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
                            drawRect(color = Color.Black, size = size / 3.5f, topLeft = Offset(0f, 0f))
                            drawRect(color = Color.Black, size = size / 3.5f, topLeft = Offset(size.width * 0.7f, 0f))
                            drawRect(color = Color.Black, size = size / 3.5f, topLeft = Offset(0f, size.height * 0.7f))
                            drawRect(color = Color.Black, size = size / 5f, topLeft = Offset(size.width * 0.4f, size.height * 0.4f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TicketStoreItem(
    emoji: String,
    title: String,
    desc: String,
    price: String,
    rewardPoints: String,
    onBuy: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(emoji, fontSize = 32.sp, modifier = Modifier.padding(end = 12.dp))
                Column {
                    Text(title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = Color.Black)
                    Text(rewardPoints, color = ForestGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(desc, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(price, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge, color = Color.Black)
                Button(
                    onClick = onBuy,
                    colors = ButtonDefaults.buttonColors(containerColor = FlamingoPink),
                    modifier = Modifier.testTag("buy_button_${title.replace(" ", "_").lowercase()}")
                ) {
                    Text("Instant Book", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==========================================
// 6. FOOD & MOBILITY ORDERING COMPONENT
// ==========================================
@Composable
fun FoodScreen(viewModel: ResortViewModel) {
    val selectedRestaurant by viewModel.selectedRestaurant.collectAsState()
    val cart by viewModel.cart.collectAsState()
    val activeOrders by viewModel.activeFoodOrders.collectAsState()

    var activeCategoryFilter by remember { mutableStateOf("All") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("food_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Mobile Food Ordering",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = ForestGreen
                )
                Text(
                    text = "Browse restaurants, menus & pay ahead",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        // Restaurant Category filters
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("All", "Pizza", "Burgers", "Yorkshire Food", "Ice Cream").forEach { filter ->
                    item {
                        FilterChip(
                            selected = activeCategoryFilter == filter,
                            onClick = { activeCategoryFilter = filter },
                            label = { Text(filter) }
                        )
                    }
                }
            }
        }

        // Cart floating preview
        if (cart.isNotEmpty()) {
            val total = cart.sumOf { it.first.price * it.second }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = FlamingoPink.copy(alpha = 0.08f)),
                    border = BorderStroke(2.dp, FlamingoPink)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Your Food Order Cart", fontWeight = FontWeight.Bold, color = FlamingoPink)
                            Text("Total: £${String.format("%.2f", total)}", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        cart.forEach { item ->
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("${item.second}x ${item.first.name}", fontSize = 12.sp, color = Color.Black)
                                Text("£${String.format("%.2f", item.first.price * item.second)}", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = { viewModel.clearCart() }, modifier = Modifier.weight(1f)) {
                                Text("Clear Cart")
                            }
                            Button(
                                onClick = { viewModel.checkoutFood() },
                                colors = ButtonDefaults.buttonColors(containerColor = FlamingoPink),
                                modifier = Modifier.weight(1f).testTag("food_checkout_button")
                            ) {
                                Text("Pay & Order Ahead", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Restaurants listing
        val filteredRestaurants = if (activeCategoryFilter == "All") {
            viewModel.staticRestaurants
        } else {
            viewModel.staticRestaurants.filter { it.category == activeCategoryFilter }
        }

        items(filteredRestaurants) { restaurant ->
            RestaurantCard(
                restaurant = restaurant,
                onClick = { viewModel.selectRestaurant(restaurant) }
            )
        }
    }

    if (selectedRestaurant != null) {
        RestaurantMenuDialog(
            restaurant = selectedRestaurant!!,
            onClose = { viewModel.selectRestaurant(null) },
            onAddToCart = { viewModel.addToCart(it) }
        )
    }
}

@Composable
fun RestaurantCard(restaurant: Restaurant, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("restaurant_card_${restaurant.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(WarmSand)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.resort_hero),
                    contentDescription = restaurant.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.2f))
                )
                Text("🍔", fontSize = 28.sp, modifier = Modifier.align(Alignment.Center))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(restaurant.name, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = Color.Black)
                Text(restaurant.category, color = FlamingoPink, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    restaurant.tags.forEach { tag ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ForestGreen.copy(alpha = 0.08f)),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Text(tag, fontSize = 9.sp, color = ForestGreen, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                    }
                }
            }

            IconButton(onClick = onClick) {
                Icon(Icons.Default.ArrowForward, contentDescription = "View Menu", tint = FlamingoPink)
            }
        }
    }
}

@Composable
fun RestaurantMenuDialog(restaurant: Restaurant, onClose: () -> Unit, onAddToCart: (MenuItem) -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(restaurant.name, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(restaurant.description, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Divider(color = Color.LightGray)

                LazyColumn(
                    modifier = Modifier.height(260.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(restaurant.menuItems) { item ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = WarmSand.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(10.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                                    Text(item.description, fontSize = 10.sp, color = Color.Gray, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text("£${String.format("%.2f", item.price)}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = ForestGreen)
                                }
                                Button(
                                    onClick = { onAddToCart(item) },
                                    colors = ButtonDefaults.buttonColors(containerColor = FlamingoPink),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.testTag("add_item_${item.name.replace(" ", "_").lowercase()}")
                                ) {
                                    Text("Add +", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) { Text("Close", fontWeight = FontWeight.Bold) }
        },
        shape = RoundedCornerShape(24.dp)
    )
}

// ==========================================
// 7. STAY SCREEN COMPONENT
// ==========================================
@Composable
fun StayScreen(viewModel: ResortViewModel) {
    val hotelBooking by viewModel.hotelBooking.collectAsState()
    val housekeepingRequested by viewModel.housekeepingRequested.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("stay_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Hotels & Holiday Village",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = ForestGreen
                )
                Text(
                    text = "Manage your resort residency & check in",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        // Active Booking Management Panel
        if (hotelBooking != null) {
            val booking = hotelBooking!!
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("🏨 Active Reservation", fontWeight = FontWeight.Bold, color = ForestGreen)
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (booking.isCheckedIn) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
                                ),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (booking.isCheckedIn) "Checked In" else "Pending Check-In",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (booking.isCheckedIn) ForestGreen else Color(0xFFFF9800),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(booking.hotelName, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge, color = Color.Black)
                        Text("Room: ${booking.roomNumber}", style = MaterialTheme.typography.bodyMedium, color = Color.DarkGray)
                        Text("Dates: ${booking.checkInDate} — ${booking.checkOutDate}", fontSize = 12.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(16.dp))

                        if (!booking.isCheckedIn) {
                            Button(
                                onClick = { viewModel.checkInHotel() },
                                modifier = Modifier.fillMaxWidth().testTag("hotel_check_in_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = FlamingoPink)
                            ) {
                                Text("Check In Now & Activate Room Key", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("🔑", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                                    Text("Digital room key active in Tickets wallet", color = ForestGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Quick Service Requests (Breakfast, Housekeeping)
            item {
                Column {
                    Text("Hotel Services", fontWeight = FontWeight.Bold, color = ForestGreen, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.bookBreakfast() },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("🍳", fontSize = 28.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Book Breakfast", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(if (booking.breakfastBooked) "✓ Booked!" else "Add buffet", fontSize = 11.sp, color = if (booking.breakfastBooked) ForestGreen else Color.Gray)
                            }
                        }

                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.requestHousekeeping() },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("🧹", fontSize = 28.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Housekeeping", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(if (housekeepingRequested) "✓ Sending towels..." else "Request towels", fontSize = 11.sp, color = if (housekeepingRequested) ForestGreen else Color.Gray)
                            }
                        }
                    }
                }
            }
        }

        // Live Evening resort entertainment schedule
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmSand.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎪", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                        Text("Resort Live Entertainment Schedule", fontWeight = FontWeight.Bold, color = ForestGreen, style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("• 19:30 — Kids Family Disco (Plaza Lodge)", fontSize = 12.sp, color = Color.Black)
                    Text("• 20:30 — Live Yorkshire Folk Music & Cabaret", fontSize = 12.sp, color = Color.Black)
                    Text("• 22:00 — Late Night Firework display (African Plains views)", fontSize = 12.sp, color = Color.Black)
                }
            }
        }
    }
}

// ==========================================
// 8. MEMBER PROFILE SCREEN COMPONENT
// ==========================================
@Composable
fun ProfileScreen(viewModel: ResortViewModel) {
    val loyaltyPoints by viewModel.loyaltyPoints.collectAsState()
    val membership by viewModel.membershipType.collectAsState()
    val badges by viewModel.badges.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("profile_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Guest Loyalty Profile",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = ForestGreen
                )
                Text(
                    text = "Track your Flamingo Explorer achievements",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        // Loyalty Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = ForestGreen),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("FLAMINGO LAND", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("Explorer Club Member", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        }
                        Text("🦩", fontSize = 36.sp)
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text("LOYALTY BALANCE", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("$loyaltyPoints Pts", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Black, fontSize = 28.sp)
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(membership, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                        }
                    }
                }
            }
        }

        // Explorer Challenges Grid Section
        item {
            Column {
                Text(
                    text = "Flamingo Explorer Challenge",
                    fontWeight = FontWeight.ExtraBold,
                    color = ForestGreen,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    badges.forEach { badge ->
                        Card(
                            modifier = Modifier.fillMaxWidth().testTag("badge_card_${badge.badgeId}"),
                            colors = CardDefaults.cardColors(
                                containerColor = if (badge.isUnlocked) Color(0xFFECF7EF) else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (badge.isUnlocked) ForestGreen.copy(alpha = 0.3f) else Color.LightGray.copy(alpha = 0.5f)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Card(
                                    shape = CircleShape,
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (badge.isUnlocked) ForestGreen else Color.LightGray.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text(badge.iconName, fontSize = 24.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = badge.title,
                                        fontWeight = FontWeight.Bold,
                                        color = if (badge.isUnlocked) ForestGreen else Color.Black
                                    )
                                    Text(badge.description, fontSize = 11.sp, color = Color.Gray)
                                }

                                if (badge.isUnlocked) {
                                    Text("Unlocked! ✓", fontWeight = FontWeight.Bold, color = ForestGreen, fontSize = 11.sp)
                                } else {
                                    Text("Locked", fontSize = 11.sp, color = Color.LightGray, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// AI ASSISTANT OVERLAY COMPONENT (GEMINI REST)
// ==========================================
@Composable
fun AiAssistantPanel(viewModel: ResortViewModel, onClose: () -> Unit) {
    val messages by viewModel.chatMessages.collectAsState()
    val isLoading by viewModel.chatLoading.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.4f))
            .clickable(onClick = onClose) // tap background to close
    ) {
        Card(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .clickable(enabled = false) {} // prevent tap propagation
                .shadow(16.dp, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)),
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header of panel
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ForestGreen)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("✨", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                        Column {
                            Text("Flamingo Resort AI Assistant", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                            Text("Asking about coffee, tigers, or itineraries?", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                        }
                    }

                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                // Chat Messages Panel
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (messages.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 48.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("🦩", fontSize = 56.sp)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("Ey up! How can I help you today, love?", fontWeight = FontWeight.Bold, color = ForestGreen)
                                Text(
                                    text = "Ask me anything, like: 'Where is coffee?', 'How long is Velocity queue?' or 'Where are giraffes?'",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 24.dp)
                                )
                            }
                        }
                    } else {
                        items(messages) { msg ->
                            val isAssistant = msg.sender == "assistant"
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = if (isAssistant) Alignment.CenterStart else Alignment.CenterEnd
                            ) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isAssistant) Color(0xFFF1F1F1) else FlamingoPink
                                    ),
                                    shape = RoundedCornerShape(
                                        topStart = 16.dp,
                                        topEnd = 16.dp,
                                        bottomStart = if (isAssistant) 0.dp else 16.dp,
                                        bottomEnd = if (isAssistant) 16.dp else 0.dp
                                    ),
                                    modifier = Modifier.widthIn(max = 280.dp)
                                ) {
                                    Text(
                                        text = msg.text,
                                        color = if (isAssistant) Color.Black else Color.White,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (isLoading) {
                        item {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = ForestGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("AI Assistant is thinking...", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Input bar panel
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmSand.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = { Text("Ask something (e.g. Where are giraffes?)") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("ai_chat_input"),
                            shape = RoundedCornerShape(24.dp),
                            colors = TextFieldDefaults.colors(
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                if (inputText.isNotBlank()) {
                                    viewModel.sendChatMessage(inputText)
                                    inputText = ""
                                }
                            },
                            modifier = Modifier
                                .background(ForestGreen, CircleShape)
                                .size(44.dp)
                                .testTag("ai_send_button")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}
