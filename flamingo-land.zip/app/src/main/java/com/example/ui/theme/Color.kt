package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FlamingoPink = Color(0xFFDB2777) // Pink 600 from Design Theme
val ForestGreen = Color(0xFF16A34A) // Green 600 from Design Theme
val YorkshireSkyBlue = Color(0xFF2563EB) // Blue 600 from Design Theme
val WarmSand = Color(0xFFFDF8F6) // Peach background from Design Theme

val Pink500 = Color(0xFFEC4899)
val Rose600 = Color(0xFFE11D48)
val Slate900 = Color(0xFF0F172A)
val Slate500 = Color(0xFF64748B)
val Slate100 = Color(0xFFF1F5F9)
val Blue600 = Color(0xFF2563EB)
val Blue50 = Color(0xFFEFF6FF)
val Green600 = Color(0xFF16A34A)
val Green50 = Color(0xFFF0FDF4)
val Pink100 = Color(0xFFFCE7F3)

val FlamingoPinkDark = Color(0xFFFF2A65)
val ForestGreenDark = Color(0xFF13321C)
val YorkshireSkyBlueDark = Color(0xFF1A5A75)

val BackgroundLight = Color(0xFFFDF8F6) // Peach/warm-sand background
val SurfaceLight = Color(0xFFFFFFFF) // White cards

val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)

